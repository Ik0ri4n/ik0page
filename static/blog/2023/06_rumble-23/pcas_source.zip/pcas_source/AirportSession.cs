﻿// Decompiled with JetBrains decompiler
// Type: Pcas.AirportSession
// Assembly: pcas, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C8B431FC-6CAF-415F-B2E8-5A8638195311
// Assembly location: pcas.dll inside K:\pcas)

using System;
using System.Buffers;
using System.Collections.Generic;
using System.IO.Pipelines;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;


#nullable enable
namespace Pcas
{
  internal class AirportSession
  {
    private AirportSession.SessionState _state;
    private readonly Airport _airport;
    private int _runwayNumber;
    private Plane _plane;
    private List<Container> _cargo = new List<Container>();
    private readonly CancellationTokenSource _sessionCancel;
    private Socket _socket;
    private readonly string _flag;

    public AirportSession([In] Airport obj0, CancellationToken _param2 = default (CancellationToken))
    {
      this._airport = obj0;
      this._sessionCancel = CancellationTokenSource.CreateLinkedTokenSource(obj0.AirportClosing, _param2);
      this._flag = Environment.GetEnvironmentVariable("FLAG") ?? "CSR{not_a_flag}";
    }

    public async Task Interact([In] Socket obj0)
    {
      this._socket = obj0;
      await this._socket.SendLineAsync("Welcome to Campbell Airstrip, Anchorage.\n");
      if (this._airport.AllCrashed())
      {
        await this._socket.SendLineAsync("We're very sorry. All runways are currently blocked by crashed planes.\nHere is a flag for your inconvenience: " + this._flag + ".");
      }
      else
      {
        this._runwayNumber = this._airport.GetAvailableRunway();
        if (this._runwayNumber == -1)
        {
          await this._socket.SendLineAsync("All runways are currently busy. Please try again at a later time.");
        }
        else
        {
          Socket socket = this._socket;
          DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(48, 1);
          interpolatedStringHandler.AppendLiteral("Runway ");
          interpolatedStringHandler.AppendFormatted<int>(this._runwayNumber);
          interpolatedStringHandler.AppendLiteral(" is available. Please provide a callsign:");
          string stringAndClear = interpolatedStringHandler.ToStringAndClear();
          await socket.SendLineAsync(stringAndClear);
          Pipe pipe = new Pipe();
          await Task.WhenAll(this.ReceiveData(pipe.Writer), this.AssembleData(pipe.Reader));
        }
      }
    }

    private async Task ReceiveData([In] PipeWriter obj0)
    {
      CancellationToken token = this._sessionCancel.Token;
      try
      {
        while (this._socket.Connected)
        {
          int async = await this._socket.ReceiveAsync(obj0.GetMemory(512), (SocketFlags) 0, token);
          if (async != 0)
          {
            obj0.Advance(async);
            if ((await obj0.FlushAsync(token)).IsCompleted)
              break;
          }
          else
            break;
        }
      }
      catch (OperationCanceledException ex)
      {
      }
      finally
      {
        await obj0.CompleteAsync();
      }
      token = new CancellationToken();
    }

    private async Task AssembleData([In] PipeReader obj0)
    {
      try
      {
        while (true)
        {
          ReadResult result = await obj0.ReadAsync(this._sessionCancel.Token);
          ReadOnlySequence<byte> buffer = result.Buffer;
          ReadOnlySequence<byte> readOnlySequence;
          while (this.TryReadLine(ref buffer, out readOnlySequence))
            await this.ProcessLine(readOnlySequence);
          obj0.AdvanceTo(buffer.Start, buffer.End);
          if (!result.IsCompleted)
          {
            result = new ReadResult();
            buffer = new ReadOnlySequence<byte>();
          }
          else
            break;
        }
      }
      catch (OperationCanceledException ex)
      {
      }
      finally
      {
        await obj0.CompleteAsync();
      }
    }

    private bool TryReadLine([In] ref ReadOnlySequence<byte> obj0, out ReadOnlySequence<byte> _param2)
    {
      SequencePosition? nullable = obj0.PositionOf<byte>((byte) 10);
      if (!nullable.HasValue)
      {
        _param2 = new ReadOnlySequence<byte>();
        return false;
      }
      _param2 = obj0.Slice(0, nullable.Value);
      obj0 = obj0.Slice(obj0.GetPosition(1L, nullable.Value));
      return true;
    }

    private async Task ProcessLine([In] ReadOnlySequence<byte> obj0_1)
    {
      AirportSession airportSession = this;
      string line = Encoding.UTF8.GetString(in obj0_1).Trim();
      switch (airportSession._state)
      {
        case AirportSession.SessionState.WaitingForPlane:
          if (!Regex.IsMatch(line, "^[A-Z]{3}[A-Z0-9]{1,}$"))
          {
            await airportSession._socket.SendLineAsync("Invalid callsign. Please consult 'Designators for Aircraft Operating Agencies, Aeronautical Authorities and Services (ICAO Doc 8585/203)'.\nPlease provide a callsign:");
            line = (string) null;
            break;
          }
          Plane plane = await airportSession._airport.GetPlane(airportSession._runwayNumber);
          airportSession._plane = plane;
          airportSession._plane.CallSign = line;
          airportSession._state = AirportSession.SessionState.PlaneAssigned;
          Socket socket1 = airportSession._socket;
          DefaultInterpolatedStringHandler interpolatedStringHandler1 = new DefaultInterpolatedStringHandler(131, 4);
          interpolatedStringHandler1.AppendLiteral("Your plane is ready.\nPlane information:\nCallsign: ");
          interpolatedStringHandler1.AppendFormatted(airportSession._plane.CallSign);
          interpolatedStringHandler1.AppendLiteral("\nTakeoff runway: ");
          interpolatedStringHandler1.AppendFormatted<int>(airportSession._plane.RunwayNumber);
          interpolatedStringHandler1.AppendLiteral("\nNumber of containers: ");
          interpolatedStringHandler1.AppendFormatted<uint>(airportSession._plane.NumberOfContainers);
          interpolatedStringHandler1.AppendLiteral("\nMax takeoff weight: ");
          interpolatedStringHandler1.AppendFormatted<uint>(airportSession._plane.MaxTakeoffWeight);
          interpolatedStringHandler1.AppendLiteral("\nProvide cargo data:");
          string stringAndClear1 = interpolatedStringHandler1.ToStringAndClear();
          await socket1.SendLineAsync(stringAndClear1);
          line = (string) null;
          break;
        case AirportSession.SessionState.PlaneAssigned:
          if (line == "END")
          {
            if ((long) airportSession._cargo.Count < (long) (airportSession._plane.NumberOfContainers / 2U))
            {
              await airportSession._socket.SendLineAsync("It's not economical to take off with so little cargo.");
              line = (string) null;
              break;
            }
            await airportSession._socket.SendLineAsync("Loading plane...");
            (Plane, TimeSpan, bool) valueTuple = await airportSession._airport.LoadPlane(airportSession._cargo, airportSession._plane);
            airportSession._plane = valueTuple.Item1;
            TimeSpan timeSpan = valueTuple.Item2;
            if (valueTuple.Item3)
            {
              await airportSession._socket.SendLineAsync("This is too complicated! You're just trying to waste our time...\nI'd rather clean up than do this!");
              airportSession._airport.CancelFlight(airportSession._plane);
              airportSession._airport.CleanUp();
              throw new CloseConnectionException();
            }
            Socket socket2 = airportSession._socket;
            DefaultInterpolatedStringHandler interpolatedStringHandler2 = new DefaultInterpolatedStringHandler(37, 2);
            interpolatedStringHandler2.AppendLiteral("Loaded plane in ");
            interpolatedStringHandler2.AppendFormatted<double>(timeSpan.TotalSeconds);
            interpolatedStringHandler2.AppendLiteral(" s. Cargo weight is ");
            interpolatedStringHandler2.AppendFormatted<uint>(airportSession._plane.CurrentWeight);
            interpolatedStringHandler2.AppendLiteral(".");
            string stringAndClear2 = interpolatedStringHandler2.ToStringAndClear();
            await socket2.SendLineAsync(stringAndClear2);
            await airportSession._socket.SendLineAsync("Requesting taxi clearance...");
            if (await airportSession._airport.RequestTaxi(airportSession._plane))
            {
              airportSession._state = AirportSession.SessionState.Taxiing;
              await airportSession._socket.SendLineAsync("Taxi clearance granted. Press Enter to taxi.");
              line = (string) null;
              break;
            }
            airportSession._state = AirportSession.SessionState.WaitingForTaxi;
            await airportSession._socket.SendLineAsync("Taxi clearance rejected. Try again later.");
            line = (string) null;
            break;
          }
          int num = 0;
          try
          {
            if ((long) airportSession._cargo.Count == (long) airportSession._plane.NumberOfContainers)
            {
              await airportSession._socket.SendLineAsync("No more containers available.");
              line = (string) null;
              break;
            }
            uint[] array = Enumerable.ToArray<uint>(Enumerable.Select<string, uint>((IEnumerable<string>) line.Split(' '), (Func<string, uint>) (obj0_2 => uint.Parse(obj0_2))));
            airportSession._cargo.Add(new Container(array[0], array[1]));
          }
          catch
          {
            num = 1;
          }
          if (num != 1)
          {
            line = (string) null;
            break;
          }
          await airportSession._socket.SendLineAsync("Invalid container!");
          line = (string) null;
          break;
        case AirportSession.SessionState.WaitingForTaxi:
          if (line == "CANCEL")
          {
            await airportSession._socket.SendLineAsync("Your flight has been cancelled.");
            airportSession._airport.CancelFlight(airportSession._plane);
            throw new CloseConnectionException();
          }
          if (await airportSession._airport.RequestTaxi(airportSession._plane))
          {
            airportSession._state = AirportSession.SessionState.Taxiing;
            await airportSession._socket.SendLineAsync("Taxi clearance granted. Press Enter to taxi.");
            line = (string) null;
            break;
          }
          await airportSession._socket.SendLineAsync("Taxi clearance rejected. Try again later.");
          line = (string) null;
          break;
        case AirportSession.SessionState.Taxiing:
          await airportSession._socket.SendLineAsync("Taxiing...");
          await airportSession._airport.Taxi();
          await airportSession._socket.SendLineAsync("Takeoff clearance granted.");
          if (await airportSession._airport.Takeoff(airportSession._plane))
          {
            airportSession._state = AirportSession.SessionState.Takeoff;
            await airportSession._socket.SendLineAsync("Takeoff successful.");
            line = (string) null;
            break;
          }
          airportSession._state = AirportSession.SessionState.Crashed;
          await airportSession._socket.SendLineAsync("Ooops. Seems like your plane just crashed.");
          // ISSUE: reference to a compiler-generated method
          Task.Run(new Func<Task>(airportSession.\u003CProcessLine\u003Eb__14_0));
          line = (string) null;
          break;
        case AirportSession.SessionState.Takeoff:
          await airportSession._socket.SendLineAsync("Your plane is flying already. Don't you have something better to do?");
          throw new CloseConnectionException();
        case AirportSession.SessionState.Crashed:
          await airportSession._socket.SendLineAsync("A plane just crashed. Could you be a bit more patient?");
          throw new CloseConnectionException();
        default:
          line = (string) null;
          break;
      }
    }

    private enum SessionState
    {
      WaitingForPlane,
      PlaneAssigned,
      WaitingForTaxi,
      Taxiing,
      Takeoff,
      Crashed,
    }
  }
}
