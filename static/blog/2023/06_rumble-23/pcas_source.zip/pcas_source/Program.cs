﻿// Decompiled with JetBrains decompiler
// Type: Pcas.Program
// Assembly: pcas, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C8B431FC-6CAF-415F-B2E8-5A8638195311
// Assembly location: pcas.dll inside K:\pcas)

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


#nullable enable
namespace Pcas
{
  internal static class Program
  {
    private static ConcurrentDictionary<string, Airport> _activeAirports = new ConcurrentDictionary<string, Airport>();

    private static void RegisterCleanup()
    {
      Timer timer = new Timer((TimerCallback) delegate
      {
        DateTime now = DateTime.UtcNow;
        foreach (string str in Enumerable.Select<KeyValuePair<string, Airport>, string>(Enumerable.Where<KeyValuePair<string, Airport>>((IEnumerable<KeyValuePair<string, Airport>>) Program._activeAirports, (Func<KeyValuePair<string, Airport>, bool>) (obj0 => now - obj0.Value.CreationTime > TimeSpan.FromMinutes(5.0))), (Func<KeyValuePair<string, Airport>, string>) (obj0 => obj0.Key)))
        {
          Airport airport;
          CollectionExtensions.Remove<string, Airport>((IDictionary<string, Airport>) Program._activeAirports, str, ref airport);
          airport?.Dispose();
        }
      }, (object) null, TimeSpan.Zero, TimeSpan.FromMinutes(1.0));
    }

    private static void HandleConnection([In] Socket obj0)
    {
      CancellationTokenSource cts = new CancellationTokenSource(TimeSpan.FromMinutes(2.0));
      Task.Run((Func<Task>) (async () =>
      {
        try
        {
          await new AirportSession(await Program.GetAirport(obj0), cts.Token).Interact(obj0);
        }
        catch (OperationCanceledException ex)
        {
          await obj0.SendLineAsync("Timeout!");
        }
        catch (CloseConnectionException ex)
        {
        }
        catch (Exception ex)
        {
          if (obj0.Connected)
            await obj0.SendLineAsync("Error!");
          if (ex.Message != "Connection reset by peer" && ex.Message != "Broken pipe")
            Console.WriteLine((object) ex);
        }
        finally
        {
          if (obj0.Connected)
          {
            obj0.Shutdown((SocketShutdown) 2);
            obj0.Close(100);
          }
          obj0.Dispose();
        }
      }), cts.Token);
    }

    private static async Task<Airport> GetAirport([In] Socket obj0)
    {
      await obj0.SendLineAsync("Welcome to PCaS. Please enter your ticket or use 00000000 for a new one:");
      byte[] numArray = new byte[9];
      obj0.Receive(numArray);
      string str1 = Encoding.UTF8.GetString(numArray).TrimEnd('\n');
      if (str1 == "00000000")
      {
        Airport airport = new Airport();
        string str2 = Path.GetRandomFileName().Substring(0, 8);
        if (!Program._activeAirports.TryAdd(str2, airport))
        {
          await obj0.SendLineAsync("Ticket collision!");
          throw new CloseConnectionException();
        }
        await obj0.SendLineAsync("Your ticket is: " + str2);
        return airport;
      }
      Airport airport1;
      if (!Program._activeAirports.TryGetValue(str1, ref airport1))
      {
        await obj0.SendLineAsync("Invalid ticket!");
        throw new CloseConnectionException();
      }
      return airport1;
    }

    public static async Task Main()
    {
      Program.RegisterCleanup();
      using (Socket socket = new Socket((SocketType) 1, (ProtocolType) 6))
      {
        socket.Bind((EndPoint) new IPEndPoint(System.Net.IPAddress.Any, 3284));
        socket.Listen();
        while (true)
          Program.HandleConnection(await socket.AcceptAsync());
      }
    }
  }
}
