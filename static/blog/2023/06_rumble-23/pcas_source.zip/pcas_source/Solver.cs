﻿// Decompiled with JetBrains decompiler
// Type: Pcas.Solver
// Assembly: pcas, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C8B431FC-6CAF-415F-B2E8-5A8638195311
// Assembly location: pcas.dll inside K:\pcas)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;


#nullable enable
namespace Pcas
{
  internal static class Solver
  {
    private static uint GreedyOptimize(
      [In] Span<Container> obj0,
      [In] uint obj1,
      [In] uint obj2,
      [In] uint obj3,
      out uint _param4,
      bool _param5 = true)
    {
      Span<Container> span = obj0;
      for (int index = 0; index < span.Length; ++index)
      {
        Container container = span[index];
        if (obj1 + container.Weight <= obj3)
        {
          obj1 += container.Weight;
          obj2 += container.Value;
        }
        else
        {
          if (_param5)
          {
            obj2 += (uint) float.Ceiling(container.Priority() * (float) (obj3 - obj1));
            break;
          }
          break;
        }
      }
      _param4 = obj1;
      return obj2;
    }

    public static (uint profit, uint weight) Solve(
      IEnumerable<Container> _param0,
      [In] uint obj1_1,
      [In] CancellationToken obj2)
    {
      Span<Container> span1 = Enumerable.ToArray<Container>((IEnumerable<Container>) Enumerable.OrderByDescending<Container, float>(Enumerable.Where<Container>(_param0, (Func<Container, bool>) (obj0 => obj0.Weight <= obj1_1)), (Func<Container, float>) (obj0 => obj0.Priority()))).AsSpan<Container>();
      if (span1.Length == 0)
        return (0U, 0U);
      uint num1;
      uint num2 = Solver.GreedyOptimize(span1, 0U, 0U, obj1_1, out num1, false);
      PriorityQueue<Solver.Node, uint> priorityQueue = new PriorityQueue<Solver.Node, uint>((IComparer<uint>) Comparer<uint>.Create((Comparison<uint>) ((obj0, obj1_2) => obj1_2.CompareTo(obj0))));
      priorityQueue.Enqueue(new Solver.Node(0, 0U, 0U), 0U);
      Solver.Node node;
      uint num3;
      while (priorityQueue.TryDequeue(ref node, ref num3))
      {
        obj2.ThrowIfCancellationRequested();
        int num4 = node.Index + 1;
        Container container = span1[node.Index];
        if (num4 == span1.Length)
        {
          num2 = node.Weight + container.Weight > obj1_1 ? Math.Max(num2, node.Profit) : Math.Max(num2, node.Profit + container.Value);
        }
        else
        {
          Span<Container> span2 = span1;
          int num5 = num4;
          uint num6 = Solver.GreedyOptimize(span2.Slice(num5, span2.Length - num5), node.Weight, node.Profit, obj1_1, out num3);
          if (num6 > num2)
            priorityQueue.Enqueue(new Solver.Node(num4, node.Weight, node.Profit), num6);
          if (node.Weight + container.Weight < obj1_1)
          {
            uint num7 = node.Weight + container.Weight;
            uint num8 = node.Profit + container.Value;
            span2 = span1;
            int num9 = num4;
            uint num10 = Solver.GreedyOptimize(span2.Slice(num9, span2.Length - num9), num7, num8, obj1_1, out num3);
            if (num10 > num2)
              priorityQueue.Enqueue(new Solver.Node(num4, num7, num8), num10);
          }
        }
      }
      return (num2, num1);
    }

    private struct Node : IEquatable<Solver.Node>
    {
      public Node([In] int obj0, [In] uint obj1, [In] uint obj2)
      {
        this.Index = obj0;
        this.Weight = obj1;
        this.Profit = obj2;
      }

      public int Index { get; }

      public uint Weight { get; }

      public uint Profit { get; }

      [CompilerGenerated]
      public override readonly 
      #nullable disable
      string ToString()
      {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.Append(nameof (Node));
        stringBuilder.Append(" { ");
        // ISSUE: reference to a compiler-generated method
        if (this.PrintMembers(stringBuilder))
          stringBuilder.Append(' ');
        stringBuilder.Append('}');
        return stringBuilder.ToString();
      }

      [CompilerGenerated]
      public override readonly int GetHashCode() => (EqualityComparer<int>.Default.GetHashCode(this.\u003CIndex\u003Ek__BackingField) * -1521134295 + EqualityComparer<uint>.Default.GetHashCode(this.\u003CWeight\u003Ek__BackingField)) * -1521134295 + EqualityComparer<uint>.Default.GetHashCode(this.\u003CProfit\u003Ek__BackingField);

      [CompilerGenerated]
      public override readonly bool Equals([In] object obj0) => obj0 is Solver.Node node && this.Equals(node);

      [CompilerGenerated]
      public readonly bool Equals([In] Solver.Node obj0) => EqualityComparer<int>.Default.Equals(this.\u003CIndex\u003Ek__BackingField, obj0.\u003CIndex\u003Ek__BackingField) && EqualityComparer<uint>.Default.Equals(this.\u003CWeight\u003Ek__BackingField, obj0.\u003CWeight\u003Ek__BackingField) && EqualityComparer<uint>.Default.Equals(this.\u003CProfit\u003Ek__BackingField, obj0.\u003CProfit\u003Ek__BackingField);
    }
  }
}
