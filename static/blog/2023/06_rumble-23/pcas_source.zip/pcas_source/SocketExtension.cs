﻿// Decompiled with JetBrains decompiler
// Type: SocketExtension
// Assembly: pcas, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C8B431FC-6CAF-415F-B2E8-5A8638195311
// Assembly location: pcas.dll inside K:\pcas)

using System;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;


#nullable enable
internal static class SocketExtension
{
  public static async Task SendLineAsync([In] this Socket obj0, [In] string obj1)
  {
    byte[] bytes = Encoding.UTF8.GetBytes(obj1 + "\n");
    int num;
    for (int index = 0; index != bytes.Length; index = num + await obj0.SendAsync((ArraySegment<byte>) RuntimeHelpers.GetSubArray<byte>(bytes, Range.StartAt((Index) index))))
      num = index;
    bytes = (byte[]) null;
  }
}
