﻿// Decompiled with JetBrains decompiler
// Type: Pcas.CloseConnectionException
// Assembly: pcas, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C8B431FC-6CAF-415F-B2E8-5A8638195311
// Assembly location: pcas.dll inside K:\pcas)

using System;

namespace Pcas
{
  internal class CloseConnectionException : Exception
  {
  }
}
