﻿// Decompiled with JetBrains decompiler
// Type: Pcas.Plane
// Assembly: pcas, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C8B431FC-6CAF-415F-B2E8-5A8638195311
// Assembly location: pcas.dll inside K:\pcas)

using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;


#nullable enable
namespace Pcas
{
  internal struct Plane : IEquatable<Plane>
  {
    public string CallSign { get; [param: In] set; }

    public uint NumberOfContainers { get; [param: In] set; }

    public uint MaxTakeoffWeight { get; [param: In] set; }

    public uint CurrentWeight { get; [param: In] set; }

    public int RunwayNumber { get; [param: In] set; }

    [CompilerGenerated]
    public override readonly 
    #nullable disable
    string ToString()
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append(nameof (Plane));
      stringBuilder.Append(" { ");
      // ISSUE: reference to a compiler-generated method
      if (this.PrintMembers(stringBuilder))
        stringBuilder.Append(' ');
      stringBuilder.Append('}');
      return stringBuilder.ToString();
    }

    [CompilerGenerated]
    public override readonly int GetHashCode() => (((EqualityComparer<string>.Default.GetHashCode(this.\u003CCallSign\u003Ek__BackingField) * -1521134295 + EqualityComparer<uint>.Default.GetHashCode(this.\u003CNumberOfContainers\u003Ek__BackingField)) * -1521134295 + EqualityComparer<uint>.Default.GetHashCode(this.\u003CMaxTakeoffWeight\u003Ek__BackingField)) * -1521134295 + EqualityComparer<uint>.Default.GetHashCode(this.\u003CCurrentWeight\u003Ek__BackingField)) * -1521134295 + EqualityComparer<int>.Default.GetHashCode(this.\u003CRunwayNumber\u003Ek__BackingField);

    [CompilerGenerated]
    public override readonly bool Equals([In] object obj0) => obj0 is Plane plane && this.Equals(plane);

    [CompilerGenerated]
    public readonly bool Equals([In] Plane obj0) => EqualityComparer<string>.Default.Equals(this.\u003CCallSign\u003Ek__BackingField, obj0.\u003CCallSign\u003Ek__BackingField) && EqualityComparer<uint>.Default.Equals(this.\u003CNumberOfContainers\u003Ek__BackingField, obj0.\u003CNumberOfContainers\u003Ek__BackingField) && EqualityComparer<uint>.Default.Equals(this.\u003CMaxTakeoffWeight\u003Ek__BackingField, obj0.\u003CMaxTakeoffWeight\u003Ek__BackingField) && EqualityComparer<uint>.Default.Equals(this.\u003CCurrentWeight\u003Ek__BackingField, obj0.\u003CCurrentWeight\u003Ek__BackingField) && EqualityComparer<int>.Default.Equals(this.\u003CRunwayNumber\u003Ek__BackingField, obj0.\u003CRunwayNumber\u003Ek__BackingField);
  }
}
