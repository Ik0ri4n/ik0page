﻿// Decompiled with JetBrains decompiler
// Type: Pcas.Container
// Assembly: pcas, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C8B431FC-6CAF-415F-B2E8-5A8638195311
// Assembly location: pcas.dll inside K:\pcas)

using System.Runtime.InteropServices;

namespace Pcas
{
  internal struct Container
  {
    public uint Weight { get; [param: In] init; }

    public uint Value { get; [param: In] init; }

    public Container([In] uint obj0, [In] uint obj1)
    {
      this.Weight = obj0;
      this.Value = obj1;
    }

    public float Priority() => (float) this.Value / (float) this.Weight;
  }
}
