﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: Extension]
[assembly: AssemblyCompany("pcas")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyProduct("pcas")]
[assembly: AssemblyTitle("pcas")]
