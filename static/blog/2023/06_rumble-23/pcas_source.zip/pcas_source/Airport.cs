﻿// Decompiled with JetBrains decompiler
// Type: Pcas.Airport
// Assembly: pcas, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C8B431FC-6CAF-415F-B2E8-5A8638195311
// Assembly location: pcas.dll inside K:\pcas)

using DotNext.Threading;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


#nullable enable
namespace Pcas
{
  internal class Airport : IDisposable
  {
    private readonly List<Airport.Runway> _runways;
    private readonly CancellationTokenSource _workThreadCancel;
    private readonly BlockingCollection<Airport.LoadInformation> _workQueue;
    private AutoResetEvent _resultSignal;
    private object _resultLock = new object();
    private Airport.LoadResult _result;
    private Thread? _workThread;

    public DateTime CreationTime { get; }

    public CancellationToken AirportClosing => this._workThreadCancel.Token;

    public Airport()
    {
      this.CreationTime = DateTime.UtcNow;
      this._workThreadCancel = new CancellationTokenSource();
      this._workQueue = new BlockingCollection<Airport.LoadInformation>();
      this._resultSignal = new AutoResetEvent(false);
      new Thread(new ThreadStart(this.DoWork)).Start();
      this._runways = new List<Airport.Runway>();
      for (int index = 1; index <= 3; ++index)
        this._runways.Add(new Airport.Runway(index));
    }

    private void DoWork()
    {
      try
      {
        while (true)
        {
          Airport.LoadInformation loadInformation = this._workQueue.Take(this._workThreadCancel.Token);
          try
          {
            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource(TimeSpan.FromSeconds(15.0));
            DateTime utcNow1 = DateTime.UtcNow;
            (uint profit, uint weight) = Solver.Solve(loadInformation.Containers, loadInformation.AirplaneCapacity, cancellationTokenSource.Token);
            DateTime utcNow2 = DateTime.UtcNow;
            lock (this._resultLock)
              this._result = new Airport.LoadResult(profit, weight, utcNow2 - utcNow1, false);
          }
          catch (OperationCanceledException ex)
          {
            lock (this._resultLock)
              this._result = new Airport.LoadResult(0U, 0U, new TimeSpan(), true);
          }
          catch (Exception ex)
          {
            Console.WriteLine((object) ex);
          }
          finally
          {
            this._resultSignal.Set();
          }
        }
      }
      catch (OperationCanceledException ex)
      {
      }
    }

    public int GetAvailableRunway()
    {
      Airport.Runway runway = Enumerable.FirstOrDefault<Airport.Runway>((IEnumerable<Airport.Runway>) this._runways, (Func<Airport.Runway, bool>) (obj0 => obj0.Status == Airport.RunwayStatus.Free));
      return runway == null ? -1 : runway.Number;
    }

    public bool AllCrashed() => Enumerable.All<Airport.Runway>((IEnumerable<Airport.Runway>) this._runways, (Func<Airport.Runway, bool>) (obj0 => obj0.Status == Airport.RunwayStatus.CrashCleanup));

    public async Task<Plane> GetPlane([In] int obj0_1)
    {
      await Task.Delay(Random.Shared.Next(1000));
      Enumerable.First<Airport.Runway>((IEnumerable<Airport.Runway>) this._runways, (Func<Airport.Runway, bool>) (obj0_2 => obj0_2.Number == obj0_1)).Status = Airport.RunwayStatus.Reserved;
      return new Plane()
      {
        NumberOfContainers = (uint) Random.Shared.Next(20, 60),
        MaxTakeoffWeight = (uint) Random.Shared.Next(5, 1000),
        RunwayNumber = obj0_1
      };
    }

    public async Task<(Plane plane, TimeSpan duration, bool Timeout)> LoadPlane(
      [In] List<Container> obj0,
      [In] Plane obj1)
    {
      Airport airport = this;
      if (airport._workThread == null || !airport._workThread.IsAlive)
      {
        airport._workThread = new Thread(new ThreadStart(airport.DoWork));
        airport._workThread.Start();
      }
      await Task.Delay(Random.Shared.Next(1000));
      airport._workQueue.Add(new Airport.LoadInformation((IEnumerable<Container>) obj0, obj1.MaxTakeoffWeight));
      int num = await airport._resultSignal.WaitAsync() ? 1 : 0;
      (Plane, TimeSpan, bool) valueTuple;
      lock (airport._resultLock)
      {
        obj1.CurrentWeight = airport._result.Weight;
        valueTuple = (obj1, airport._result.Duration, airport._result.Timeout);
      }
      return valueTuple;
    }

    public async Task<bool> RequestTaxi([In] Plane obj0_1)
    {
      bool cleared = false;
      Airport.Runway runway = Enumerable.First<Airport.Runway>((IEnumerable<Airport.Runway>) this._runways, (Func<Airport.Runway, bool>) (obj0_2 => obj0_2.Number == obj0_1.RunwayNumber));
      if (runway.Status == Airport.RunwayStatus.Reserved)
      {
        runway.Status = Airport.RunwayStatus.Taxiing;
        cleared = true;
      }
      await Task.Delay(Random.Shared.Next(1000));
      return cleared;
    }

    public Task Taxi() => Task.Delay(Random.Shared.Next(1000));

    public async Task<bool> Takeoff([In] Plane obj0_1)
    {
      await Task.Delay(Random.Shared.Next(1000));
      int num = obj0_1.CurrentWeight > obj0_1.MaxTakeoffWeight ? 1 : 0;
      Enumerable.First<Airport.Runway>((IEnumerable<Airport.Runway>) this._runways, (Func<Airport.Runway, bool>) (obj0_2 => obj0_2.Number == obj0_1.RunwayNumber)).Status = num == 0 ? Airport.RunwayStatus.Free : Airport.RunwayStatus.CrashCleanup;
      return num == 0;
    }

    public void CancelFlight([In] Plane obj0_1)
    {
      Airport.Runway runway = Enumerable.First<Airport.Runway>((IEnumerable<Airport.Runway>) this._runways, (Func<Airport.Runway, bool>) (obj0_2 => obj0_2.Number == obj0_1.RunwayNumber));
      if (runway.Status != Airport.RunwayStatus.Reserved && runway.Status != Airport.RunwayStatus.Taxiing)
        return;
      runway.Status = Airport.RunwayStatus.Free;
    }

    public void Dispose()
    {
      this._resultSignal.Dispose();
      this._workThreadCancel.Cancel();
    }

    internal void CleanUp()
    {
      Airport.Runway runway = Enumerable.FirstOrDefault<Airport.Runway>((IEnumerable<Airport.Runway>) this._runways, (Func<Airport.Runway, bool>) (obj0 => obj0.Status == Airport.RunwayStatus.CrashCleanup));
      if (runway == null)
        return;
      runway.Status = Airport.RunwayStatus.Free;
    }

    private struct LoadInformation : IEquatable<Airport.LoadInformation>
    {
      public LoadInformation([In] IEnumerable<Container> obj0, [In] uint obj1)
      {
        this.Containers = obj0;
        this.AirplaneCapacity = obj1;
      }

      public IEnumerable<Container> Containers { get; }

      public uint AirplaneCapacity { get; }

      [CompilerGenerated]
      public override readonly 
      #nullable disable
      string ToString()
      {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.Append(nameof (LoadInformation));
        stringBuilder.Append(" { ");
        // ISSUE: reference to a compiler-generated method
        if (this.PrintMembers(stringBuilder))
          stringBuilder.Append(' ');
        stringBuilder.Append('}');
        return stringBuilder.ToString();
      }

      [CompilerGenerated]
      public override readonly int GetHashCode() => EqualityComparer<IEnumerable<Container>>.Default.GetHashCode(this.\u003CContainers\u003Ek__BackingField) * -1521134295 + EqualityComparer<uint>.Default.GetHashCode(this.\u003CAirplaneCapacity\u003Ek__BackingField);

      [CompilerGenerated]
      public override readonly bool Equals([In] object obj0) => obj0 is Airport.LoadInformation loadInformation && this.Equals(loadInformation);

      [CompilerGenerated]
      public readonly bool Equals([In] Airport.LoadInformation obj0) => EqualityComparer<IEnumerable<Container>>.Default.Equals(this.\u003CContainers\u003Ek__BackingField, obj0.\u003CContainers\u003Ek__BackingField) && EqualityComparer<uint>.Default.Equals(this.\u003CAirplaneCapacity\u003Ek__BackingField, obj0.\u003CAirplaneCapacity\u003Ek__BackingField);
    }

    private class LoadResult : IEquatable<Airport.LoadResult>
    {
      public LoadResult([In] uint obj0, [In] uint obj1, [In] TimeSpan obj2, [In] bool obj3)
      {
        this.Profit = obj0;
        this.Weight = obj1;
        this.Duration = obj2;
        this.Timeout = obj3;
        // ISSUE: explicit constructor call
        base.\u002Ector();
      }

      [CompilerGenerated]
      protected virtual 
      #nullable enable
      Type EqualityContract => typeof (Airport.LoadResult);

      public uint Profit { get; }

      public uint Weight { get; }

      public TimeSpan Duration { get; }

      public bool Timeout { get; }

      [CompilerGenerated]
      public override string ToString()
      {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.Append(nameof (LoadResult));
        stringBuilder.Append(" { ");
        if (this.PrintMembers(stringBuilder))
          stringBuilder.Append(' ');
        stringBuilder.Append('}');
        return stringBuilder.ToString();
      }

      [CompilerGenerated]
      protected virtual bool PrintMembers([In] StringBuilder obj0)
      {
        RuntimeHelpers.EnsureSufficientExecutionStack();
        obj0.Append("Profit = ");
        obj0.Append(this.Profit.ToString());
        obj0.Append(", Weight = ");
        obj0.Append(this.Weight.ToString());
        obj0.Append(", Duration = ");
        obj0.Append(this.Duration.ToString());
        obj0.Append(", Timeout = ");
        obj0.Append(this.Timeout.ToString());
        return true;
      }

      [CompilerGenerated]
      public override int GetHashCode() => (((EqualityComparer<Type>.Default.GetHashCode(this.EqualityContract) * -1521134295 + EqualityComparer<uint>.Default.GetHashCode(this.\u003CProfit\u003Ek__BackingField)) * -1521134295 + EqualityComparer<uint>.Default.GetHashCode(this.\u003CWeight\u003Ek__BackingField)) * -1521134295 + EqualityComparer<TimeSpan>.Default.GetHashCode(this.\u003CDuration\u003Ek__BackingField)) * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(this.\u003CTimeout\u003Ek__BackingField);

      [CompilerGenerated]
      public override bool Equals([In] object? obj0) => this.Equals(obj0 as Airport.LoadResult);

      [CompilerGenerated]
      public virtual bool Equals([In] Airport.LoadResult? obj0)
      {
        if (this == obj0)
          return true;
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        return obj0 != null && this.EqualityContract == obj0.EqualityContract && EqualityComparer<uint>.Default.Equals(this.\u003CProfit\u003Ek__BackingField, obj0.\u003CProfit\u003Ek__BackingField) && EqualityComparer<uint>.Default.Equals(this.\u003CWeight\u003Ek__BackingField, obj0.\u003CWeight\u003Ek__BackingField) && EqualityComparer<TimeSpan>.Default.Equals(this.\u003CDuration\u003Ek__BackingField, obj0.\u003CDuration\u003Ek__BackingField) && EqualityComparer<bool>.Default.Equals(this.\u003CTimeout\u003Ek__BackingField, obj0.\u003CTimeout\u003Ek__BackingField);
      }
    }

    public enum RunwayStatus
    {
      Free,
      Reserved,
      Taxiing,
      CrashCleanup,
    }

    private class Runway
    {
      public readonly int Number;
      public Airport.RunwayStatus Status;

      public Runway([In] int obj0)
      {
        this.Number = obj0;
        this.Status = Airport.RunwayStatus.Free;
      }
    }
  }
}
