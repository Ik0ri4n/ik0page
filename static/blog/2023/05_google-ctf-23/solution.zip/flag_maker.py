#!/usr/bin/env python3
# GCTF'23 - Old School - Flag Maker
import hashlib

from solver import solve_password_for

# Find the passwords for the following 50 usernames, substitute them inside the pairs,
# and then run the script to get the flag.
pairs = [
  ('gdwAnDgwbRVnrJvEqzvs', '{password}'),
  ('ZQdsfjHNgCpHYnOVcGvr', '{password}'),
  ('PmJgHBtIpaWNEMKiDQYW', '{password}'),
  ('OAmhVkxiUjUQWcmCCrVj', '{password}'),
  ('ALdgOAnaBbMwhbXExKrN', '{password}'),
  ('tqBXanGeFuaRSMDmwrAo', '{password}'),
  ('etTQMfSiRlMbNSuEOFZo', '{password}'),
  ('wceLFjLkBstBfQTtwnmv', '{password}'),
  ('rBiaRSHGLToSvIAQhZIs', '{password}'),
  ('ackTeRoASCkkkRUIBjmX', '{password}'),
  ('UBFLQMizCtLCnnOjaLMa', '{password}'),
  ('UwiBcAZEAJHKmZSrLqTB', '{password}'),
  ('oYlcWeZwpEEejIGuCHSU', '{password}'),
  ('txWHHXTtBXbckmRPxgCx', '{password}'),
  ('mhPdqEbAligcqQCsHLGl', '{password}'),
  ('UsIdCFPOqrXwsSMoqfIv', '{password}'),
  ('OdSAfswQJnMyjOlqpmqJ', '{password}'),
  ('eNKVZRlVwQCxWzDvUrUW', '{password}'),
  ('dUVNMmEPDxRIdVRXzbKa', '{password}'),
  ('iMBkfiyJxewhnvxDWXWB', '{password}'),
  ('xlQgeOrNItMzSrkldUAV', '{password}'),
  ('UPEfpiDmCeOzpXeqnFSC', '{password}'),
  ('ispoleetmoreyeah1338', '{password}'),
  ('dNcnRoRDFvfJbAtLraBd', '{password}'),
  ('FKBEgCvSeebMGixUVdeI', '{password}'),
  ('DfBrZwIrsHviSIbenmKy', '{password}'),
  ('OvQEEDVvxzZGSgNOhaEW', '{password}'),
  ('iNduNnptWlmAVsszvTIZ', '{password}'),
  ('GvTcyPNIUuojKfdqCbIQ', '{password}'),
  ('noAJKHffdaRrCDOpvMyj', '{password}'),
  ('rAViEUMTbUByuosLYfMv', '{password}'),
  ('YiECebDqMOwStHZyqyhF', '{password}'),
  ('phHkOgbzfuvTWVbvRlyt', '{password}'),
  ('arRzLiMFyEqSAHeemkXJ', '{password}'),
  ('jvsYsTpHxvXCxdVyCHtM', '{password}'),
  ('yOOsAYNxQndNLuPlMoDI', '{password}'),
  ('qHRTGnlinezNZNUCFUld', '{password}'),
  ('HBBRIZfprBYDWLZOIaAd', '{password}'),
  ('kXWLSuNpCGxenDxYyalv', '{password}'),
  ('EkrdIpWkDeVGOSPJNDVr', '{password}'),
  ('pDXIOdNXHhehzlpbJYGs', '{password}'),
  ('WMkwVDmkxpoGvuLvgESM', '{password}'),
  ('aUwdXCDDUWlPQwadOliF', '{password}'),
  ('WmlngotWTsikaXRDakbp', '{password}'),
  ('thrZhzSRBzJFPrxKmetr', '{password}'),
  ('TcurEDzLjepMrNwspPqd', '{password}'),
  ('SScTJRokTraQbzQpwDTR', '{password}'),
  ('PObUeTjQTwEflLQtPOJM', '{password}'),
  ('LUDPGXGvuVFAYlMTTowZ', '{password}'),
  ('UlTVDrBlCmXmFBmwLLKX', '{password}'),
]

for i, p in enumerate(pairs):
    username = p[0]
    password = solve_password_for(username)

    pairs[i] = (username, password)

# print(pairs)

print('CTF{' + hashlib.sha1(b'|'.join(f'{u}:{p}'.encode('utf-8') for u, p in pairs)).hexdigest() + '}')
