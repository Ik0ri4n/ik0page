import subprocess
import z3

PASSWORD_MAP = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"

PTRACE_BIT = 0

SHUFFLE_MAP = [ 0x10, 0xE, 0xD, 0x2, 0xB, 0x11, 0x15, 0x1E, 0x7, 0x18, 0x12, 0x1C, 0x1A, 0x1, 0xC, 0x6, 0x1F, 0x19, 0x0, 0x17, 0x14, 0x16, 0x8, 0x1B, 0x4, 0x3, 0x13, 0x5, 0x9, 0xA, 0x1D, 0xF ]
XOR_MAP = [ 0x19, 0x2, 0x8, 0xF, 0xA, 0x1A, 0xD, 0x1E, 0x4, 0x5, 0x10, 0x7, 0xE, 0x0, 0x6, 0x1F, 0x1D, 0xB, 0x11, 0x3, 0x1C, 0x13, 0x9, 0x14, 0x1B, 0x15, 0x1, 0xC, 0x18, 0x16, 0x17, 0x12 ]

if PTRACE_BIT == 0:
    for pos in range(0x20):
        XOR_MAP[pos] ^= 2
else:
    for pos in range(0x20):
        XOR_MAP[pos] ^= 4

# gdwAnDgwbRVnrJvEqzvs
# username_list = [18,29,16,19,27,0,0,0,0,0,0,0,0,0,0,0,8,31,8,23,30,0,0,0,0,0,0,0,0,0,0,0,29,3,28,10,21,0,0,0,0,0,0,0,0,0,0,0,18,29,8,16,28,0,0,0,0,0,0,0,0,0,0,0,11,30,7,20,7,0,0,0,0,0,0,0,0,0,0,0]


def solve_for_password_list(username_list: list[int]) -> list[int]:
    solver = z3.Solver()

    password_list = [0] * 25
    for i in range(25):
        password_list[i] = z3.BitVec("p" + str(i), 4 * 8)
        solver.add(password_list[i] < 0x100)
        solver.add(password_list[i] >= 0)

    for pos in range(5):
        for index in range(5):
            local_58 = 0
            for j in range(5):
                local_58 = (
                    local_58 + username_list[j + pos * 0x10] * password_list[j * 5 + index]
                    & 0x1F
                )

            solver.add(z3.If((pos == index), (local_58 == 1), (local_58 == 0)))

    assert solver.check() == z3.sat

    model = solver.model()
    result_list = [0] * 25
    for i, p in enumerate(password_list):
        result_list[i] = model[p].as_long()

    return result_list


# gdwAnDgwbRVnrJvEqzvs
# IN_LIST = [18, 21, 12, 14, 2, 1, 31, 11, 30, 16, 21, 8, 27, 11, 26, 0, 13, 19, 2, 14, 28, 8, 12, 31, 3]

def unshuffle(in_list: list[int]) -> str:
    list1 = [0] * 25
    for round in range(5):
        for offset in range(5 - round):
            list1[round * 5 + round + offset] = in_list[round * 5 + offset]

        for offset in range(round):
            shifted = 5 - (round - offset)
            list1[round * 5 + offset] = in_list[round * 5 + shifted]

    list2 = [0] * 25
    for pos in range(5):
        for index in range(5):
            list2[pos * 5 + index] = list1[pos * 5 + index] ^ XOR_MAP[(index + pos * 5)]

    list3 = [0] * 25
    for pos in range(5):
        for index in range(5):
            list3[pos * 5 + index] = SHUFFLE_MAP.index(list2[pos * 5 + index])

    password = ""
    for block in range(5):
        for offset in range(5):
            password += PASSWORD_MAP[list3[block * 5 + offset]]

        password += "-"

    return password[:-1]


def solve_password_for(username: str) -> str:
    username_list_str = subprocess.check_output(["./generate_username_list", username])[
        :-2
    ].decode()
    username_list = [int(val, 10) for val in username_list_str.split(",")]

    password_list = solve_for_password_list(username_list)
    password = unshuffle(password_list)
    return password
