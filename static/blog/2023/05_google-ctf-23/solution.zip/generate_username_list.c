#include <string.h>
#include <stdio.h>

typedef unsigned char undefined;

typedef unsigned char byte;
typedef unsigned char dwfenc;
typedef unsigned int uint;
typedef unsigned int dword;
typedef long long longlong;
typedef unsigned long ulong;
typedef unsigned char undefined1;
typedef unsigned short undefined2;
typedef unsigned int undefined4;
typedef unsigned short ushort;
typedef unsigned short word;

const int PTRACE_BIT = 0;
int USEGEN_BASE = 0x7A69 + PTRACE_BIT * 0x7;

byte USERGEN_MAP[] = {0x3, 0xa, 0x16, 0x4, 0xc, 0x10, 0x14, 0xd, 0x16, 0xd, 0x16, 0x13, 0xe, 0xd, 0xc, 0x17, 0x7, 0x13, 0xe, 0x14, 0x1, 0xb, 0x7, 0x18, 0x19, 0xb, 0xd, 0x8, 0x9, 0x1, 0xc, 0x7, 0x14, 0x15, 0x13, 0x10, 0x6, 0x17, 0x7, 0xa, 0x12, 0x11, 0x2, 0xb, 0x4, 0x3, 0xa, 0xc, 0x5, 0x1a, 0x8, 0x6, 0xf, 0x4, 0xa, 0x0, 0xf, 0x1, 0xe, 0x9, 0xb, 0x7, 0x1, 0x19, 0x1, 0x17, 0x1, 0x9, 0x18, 0xf, 0x17, 0x13, 0x10, 0x16, 0xf, 0xc, 0x4, 0x17, 0x13, 0x18, 0x5, 0x13, 0x8, 0xd, 0x12, 0x1, 0x15, 0x7, 0x4, 0x13, 0x19, 0x8, 0x11, 0xe, 0x6, 0x17};
byte SHUFFLE_MAP[] = {0x10, 0xe, 0xd, 0x2, 0xb, 0x11, 0x15, 0x1e, 0x7, 0x18, 0x12, 0x1c, 0x1a, 0x1, 0xc, 0x6, 0x1f, 0x19, 0x0, 0x17, 0x14, 0x16, 0x8, 0x1b, 0x4, 0x3, 0x13, 0x5, 0x9, 0xa, 0x1d, 0xf};
byte XOR_MAP[] = {0x19, 0x2, 0x8, 0xf, 0xa, 0x1a, 0xd, 0x1e, 0x4, 0x5, 0x10, 0x7, 0xe, 0x0, 0x6, 0x1f, 0x1d, 0xb, 0x11, 0x3, 0x1c, 0x13, 0x9, 0x14, 0x1b, 0x15, 0x1, 0xc, 0x18, 0x16, 0x17, 0x12};


void init()
{
  byte tmp = 0;
  if (PTRACE_BIT == 0)
  {
    for (int block = 0; block < 0x20; block++)
    {
      tmp = USERGEN_MAP[0 + block * 3];
      USERGEN_MAP[0 + block * 3] = USERGEN_MAP[1 + block * 3];
      USERGEN_MAP[1 + block * 3] = tmp;
    }
  }
  else
  {
    for (int block = 0; block < 0x20; block++)
    {
      tmp = USERGEN_MAP[1 + block * 3];
      USERGEN_MAP[1 + block * 3] = USERGEN_MAP[2 + block * 3];
      USERGEN_MAP[2 + block * 3] = tmp;
    }
  }

  if (PTRACE_BIT == 0)
  {
    for (int pos = 0; pos < 0x20; pos++)
    {
      XOR_MAP[pos] ^= 2;
    }
  }
  else
  {
    for (int pos = 0; pos < 0x20; pos++)
    {
      XOR_MAP[pos] ^= 4;
    }
  }
}

undefined4 password_check_maybe(char *username, char *password)
{
  size_t len_pos;
  undefined4 result;
  byte *pbVar1;
  undefined *puVar2;
  size_t username_len;
  long i;
  int iVar3;
  uint *puVar4;
  byte bVar5;
  uint auStack_26c[3];
  byte local_25d;
  uint important[80];
  uint password_map[25];
  undefined4 local_b3[8];
  undefined auStack_92[34];
  uint local_70;
  undefined4 local_6c;
  undefined4 local_68;
  uint local_64;
  uint local_60[5];
  int local_5c;
  uint local_58;
  int local_54;
  int local_50;
  uint local_4c;
  uint local_48;
  int local_44;
  uint local_40;
  int triplets_;
  int name_blocks;
  int local_34;
  uint local_30;
  char local_29;
  uint j;
  int index;
  uint pos;

  bVar5 = 0;
  len_pos = strlen(password);
  if (len_pos == 29)
  {
    puVar4 = password_map;
    for (i = 0x19; i != 0; i = i + -1)
    {
      *puVar4 = 0;
      puVar4 = puVar4 + (uint)bVar5 * -2 + 1;
    }
    index = 0;
    for (pos = 0; password[pos] != '\0'; pos = pos + 1)
    {
      if ((((pos == 5) || (pos == 11)) || (pos == 17)) || (pos == 23))
      {
        if (password[pos] != '-')
        {
          return 0;
        }
      }
      else
      {
        local_29 = '\0';
        for (j = 0; (int)j < 0x20; j = j + 1)
        {
          char *tmp = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ";
          i = (long)tmp;
          if (*(char *)(i + j) == password[pos])
          {
            i = index / 5;
            iVar3 = index % 5;
            index = index + 1;
            password_map[i * 5 + iVar3] = j;
            local_29 = '\x01';
            break;
          }
        }
        if (local_29 != '\x01')
        {
          return 0;
        }
      }
    }
    // printf("[");
    // for (i = 0; i <25; i++) {
    //   printf("%d,", password_map[i]);
    // }
    // printf("]\n");

    local_30 = 0;
    local_34 = USEGEN_BASE;
    puVar4 = important;
    for (i = 0x50; i != 0; i = i + -1)
    {
      *puVar4 = 0;
      puVar4 = puVar4 + (uint)bVar5 * -2 + 1;
    }
    name_blocks = 0;
    triplets_ = 0;
    pos = 0;
    while (len_pos = strlen(username), pos < len_pos)
    {
      local_40 = 0;
      for (index = 0;
           (index < 4 &&
            (len_pos = index + pos, username_len = strlen(username), len_pos != username_len));
           index = index + 1)
      {
        local_40 = (int)username[index + pos] & 0x7fU | local_40 << 7;
      }
      for (j = 0; (int)j < 3; j = j + 1)
      {
        // local_6c = *(undefined4 *)(&DAT_00035160 + ((local_34 % 0x20) * 3 + j) * 4);
        // local_6c = (undefined4)(DAT_00035160[((local_34 % 0x20) * 3 + j) * 4]);
        local_6c = (undefined4)(USERGEN_MAP[((local_34 % 0x20) * 3 + j)]);
        // printf("%u-%u,",j,local_6c);
        local_30 = (int)(1 << ((byte)local_6c & 0x1f) & local_40) >> ((byte)local_6c & 0x1f) |
                   local_30 * 2;
      }
      // printf("\n");
      for (j = 0; (int)j < 3; j = j + 1)
      {
        // local_68 = *(undefined4 *)(&DAT_00035160 + ((local_34 % 0x20) * 3 + j) * 4);
        // local_68 = (undefined4)(DAT_00035160[((local_34 % 0x20) * 3 + j) * 4]);
        local_68 = (undefined4)(USERGEN_MAP[((local_34 % 0x20) * 3 + j)]);
        // printf("%u,",local_68);
        bVar5 = (byte)local_68;
        local_40 = (1 << (bVar5 & 0x1f)) - 1U & local_40 |
                   ((int)local_40 >> (bVar5 + 1 & 0x1f)) << (bVar5 & 0x1f);
      }
      // printf("\n");
      triplets_ = triplets_ + 3;
      for (j = 0; (int)j <= (int)(local_30 & 7); j = j + 1)
      {
        local_34 = (local_34 * 0x1fb9 + 0x6efb) % 0x20d38;
      }
      for (j = 0; (int)j < 5; j = j + 1)
      {
        important[j + name_blocks * 0x10] = ~local_40 & 0x1f;
        local_40 = (int)local_40 >> 5;
      }
      name_blocks = name_blocks + 1;
      pos = pos + 4;
    }
    if ((triplets_ < 0x21) && (4 < name_blocks))
    {
      for (local_44 = 4; -1 < local_44; local_44 = local_44 + -1)
      {
      }
      for (pos = 0; (int)pos < name_blocks; pos = pos + 1)
      {
        local_48 = (important[pos + 0x20] & 3) << 10 | important[pos + 0x10] << 5 | important[pos];
        local_4c = important[pos + 0x40] << 8 |
                   (int)important[pos + 0x20] >> 2 & 7U | important[pos + 0x30] << 3;
        for (index = 0; index < 0xd; index = index + 1)
        {
          local_64 = (1 << ((byte)triplets_ & 0x1f)) - 1U &
                         ~((int)local_30 >> ((byte)triplets_ - 1 & 0x1f) | local_30 * 2) ^
                     ((int)local_4c >> 0xc | local_4c * 8) & 0x7fff ^ local_48;
          local_48 = local_4c & 0x7fff;
          local_4c = local_64 & 0x7fff;
        }
        important[pos] = local_48 & 0x1f;
        important[pos + 0x10] = (int)local_48 >> 5 & 0x1f;
        important[pos + 0x20] = (int)local_48 >> 10 & 3U | local_4c & 0x1c;
        important[pos + 0x30] = (int)local_4c >> 5 & 0x1f;
        important[pos + 0x40] = (int)local_4c >> 10 & 0x1f;

        // printf("%04x\n", local_48);
        // printf("%04x\n", local_4c);
      }
      for (local_50 = 4; -1 < local_50; local_50 = local_50 + -1)
      {
      }
      for (pos = 0; (int)pos < 5; pos = pos + 1)
      {
        for (index = 0; index < 5; index = index + 1)
        {
          password_map[pos * 5 + index] =
              (uint)(SHUFFLE_MAP[password_map[pos * 5 + index]]);
        }
      }
      // printf("[");
      // for (i = 0; i <25; i++) {
      //   printf("%d,", password_map[i]);
      // }
      // printf("]\n");
      for (pos = 0; (int)pos < 5; pos = pos + 1)
      {
        for (index = 0; index < 5; index = index + 1)
        {
          password_map[pos * 5 + index] =
              password_map[pos * 5 + index] ^ (uint)(XOR_MAP[(index + pos * 5)]);
        }
      }
      // printf("[");
      // for (i = 0; i <25; i++) {
      //   printf("%d,", password_map[i]);
      // }
      // printf("]\n");

      // Another shuffle
      for (pos = 1; (int)pos < 5; pos = pos + 1)
      {
        for (index = 0; index < (int)pos; index = index + 1)
        {
          local_60[index] = password_map[pos * 5 + index];
        }
        for (index = pos; index < 5; index = index + 1)
        {
          password_map[index + pos * 4] = password_map[pos * 5 + index];
        }
        for (index = 5 - pos; index < 5; index = index + 1)
        {
          password_map[pos * 5 + index] = local_60[index + -5 + pos];
        }
      }
      for (local_54 = 4; -1 < local_54; local_54 = local_54 + -1)
      {
      }
      for (int x = 0; x < 80; x++)
      {
        printf("%u,", important[x]);
      }
      printf("\n");
      for (pos = 0; (int)pos < 5; pos = pos + 1)
      {
        for (index = 0; index < name_blocks; index = index + 1)
        {
          local_58 = 0;
          for (j = 0; (int)j < 5; j = j + 1)
          {
            local_58 = local_58 + important[j + pos * 0x10] * password_map[j * 5 + index] & 0x1f;
          }
          if (((pos == index) && (local_58 != 1)) || ((pos != index && (local_58 != 0))))
          {
            return 0;
          }
        }
      }
      result = 1;
    }
    else
    {
      result = 0;
    }
  }
  else
  {
    result = 0;
  }
  return result;
}

int main(int argc, char **argv)
{
  char *username = argv[1];
  init();
  
  password_check_maybe(username, "ABCDE-ABCDE-ABCDE-ABCDE-ABCDE");

  return 0;
}