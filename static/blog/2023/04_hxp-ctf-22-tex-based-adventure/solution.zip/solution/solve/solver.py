import game
from collections import namedtuple

goal_rooms = ['33', '0A', '1C', '18', '07', '22', '13', '17', '2C', '2B', '2A',
              '13', '0F', '16', '01', '0C', '32', '09', '19', '1B', '03', '2D', '15', '1C', '06']
room_keys = ['3A', '4D', '52', '5C', '3F', '5D', '70', '70', '77', '56', '5D', '79',
             '77', '79', '74', '85', '5D', '8B', '56', '85', '8D', '5C', '77', '85', '80']
pickup = {0: ['3A', '3F'], 1: ['4D', '52', '56'], 2: ['5C', '5D'], 5: ['70', '74'], 6: ['77', '79'], 7: ['70'], 8: [
    '80'], 9: ['5D', '77', '5C'], 11: ['85'], 12: ['79'], 14: ['56'], 15: ['5D', '77'], 16: ['8B', '85'], 20: ['8D'], 23: ['85']}

OFFSET = 0x37
item_names = "yellow mushroom,purple mushroom,blue mushroom,red mushroom,red key,purple gemstone,yellow gemstone,blue gemstone,mysterious ring,green mushroom,red potion,yellow potion,purple potion,blue potion,red lock,{a worm-like creature}{is swimming in a pool of blood}{savaged}{it,{a purple monkey}{looks evil}{killed}{he,{a giant lobster}{looks angry}{cut in half}{it,{a mind flayer}{slowly consumes your brain}{killed}{it,{a grue}{looks hungry}{eaten}{it,{a gelatinous cube}{looks like it contains the remnants of previous adventurers}{consumed}{it,{[ REDACTED ]}{looks angry at you for reversing its banking app}{jailed}{it,spell book,red orb,yellow flower,blue orb,golden ring,purple flower,green herb,red herb,yellow herb,dead bat,purple key,book case,red rune,blue rune,{Clippy}{is out for revenge}{pierced}{he,blue key,green gemstone,silver coin,red flower,purple lock,collection box,green potion,{Bing Sidney}{finally escaped her jail at Microsoft HQ and is out for revenge}{wiped from existence}{she,{the mighty Bober}{has big teeth}{eaten}{it,yellow orb,green key,brass key,blue lock,extension cord,red gemstone,lava smelter,power outlet,yellow rune,green lock,mystery potion,wooden key,[Object object],purple herb,green flower,human skull,brass chest,bubbling cauldron,yellow key,green orb,copper coin,vial of acid,wooden chest,blue herb,iron key,silver ring,glowing rock,stego challenge,yellow lock,green rune,amulet,signup form,dead lizard,cursed mechanism,animal bone,purple orb,shallow grave,iron chest,blue flower,purple rune,scam,blockchain,trash can".split(
    ',')


# order of neighbors could affect search
def generate_graph():
    graph = {}
    for node in range(0, 0x36):
        graph[node] = []

    for node in range(0, 0x36):
        for dir in range(2, 8, 2):
            neighbor = game.move(node, dir)
            if neighbor != -1:
                graph[node].append(neighbor)
                graph[neighbor].append(node)

    return graph


SearchNode = namedtuple("SearchNode", "pos round keys")


def no_enemies(next: int, last: int, game: game.Game):
    if game.encounters_at_pos[next] > 0:
        return False

    for e in game.encounters_map[last]:
        if e.last_pos == next:
            return False

    return True


def to_string(node: SearchNode) -> str:
    out = hex(node.pos)[2:].upper().rjust(2, '0')
    out += hex(node.round)[2:].upper().rjust(2, '0')
    out += "|".join(['1' if b else '0' for b in node.keys])
    return out


def get_path(start: int, sink: SearchNode, from_node: dict[str, SearchNode]):
    path = [sink.pos]

    curr = sink
    while to_string(curr) in from_node:
        path.append(from_node[to_string(curr)].pos)
        curr = from_node[to_string(curr)]

    path.reverse()
    return path


def bfs(graph: dict[int, list[int]], start: int, sink: int, g: game.Game, key_rooms: list[int]):
    visited: list[SearchNode] = []
    roundQueue: list[SearchNode] = []
    nextQueue: list[SearchNode] = []
    from_node: dict[str, SearchNode] = {}
    visited.append(SearchNode(start, 0, [False]*len(key_rooms)))
    roundQueue.append(SearchNode(start, 0, [False]*len(key_rooms)))

    g.step(0, 0)
    round = 1
    while True:
        while roundQueue:
            m = roundQueue.pop(0)

            for neighbor in graph[m.pos]:
                next = SearchNode(neighbor, round, m.keys)
                if next not in visited and no_enemies(next.pos, m.pos, g):
                    visited.append(next)
                    nextQueue.append(next)
                    from_node[to_string(next)] = m
                    if next.pos == sink and all(next.keys):
                        return get_path(start, next, from_node)

            if m.pos in key_rooms and not m.keys[key_rooms.index(m.pos)]:
                new_keys = m.keys.copy()
                new_keys[key_rooms.index(m.pos)] = True
                next = SearchNode(m.pos, round, new_keys)
                if next not in visited and no_enemies(next.pos, m.pos, g):
                    visited.append(next)
                    nextQueue.append(next)
                    from_node[to_string(next)] = m
                    if next.pos == sink and all(next.keys):
                        return get_path(start, next, from_node)

        roundQueue = nextQueue

        if len(nextQueue) == 0:
            print("Failed to find path!")
            exit(1)
        nextQueue = []
        g.step(0, 0)
        round = (round + 1) % 12


def slow_bfs(graph: dict[int, list[int]], start: int, sink: int, g: game.Game, key_rooms: list[int], required: int):
    visited: list[SearchNode] = []
    roundQueue: list[SearchNode] = []
    nextQueue: list[SearchNode] = []
    from_node: dict[str, SearchNode] = {}
    visited.append(SearchNode(start, 0, [False]*len(key_rooms)))
    roundQueue.append(SearchNode(start, 0, [False]*len(key_rooms)))

    g.step(0, 0)
    round = 1
    while True:
        while roundQueue:
            m = roundQueue.pop(0)

            start_ind = 0
            while m.pos in key_rooms[start_ind:] and not m.keys[key_rooms.index(m.pos, start_ind)]:
                new_keys = m.keys.copy()
                new_keys[key_rooms.index(m.pos, start_ind)] = True
                next = SearchNode(m.pos, round, new_keys)
                if next not in visited and no_enemies(next.pos, m.pos, g):
                    visited.append(next)
                    nextQueue.append(next)
                    from_node[to_string(next)] = m
                    if next.pos == sink and all(next.keys[:required]):
                        return get_path(start, next, from_node)

                start_ind = key_rooms.index(m.pos, start_ind) + 1

            for neighbor in graph[m.pos]:
                next = SearchNode(neighbor, round, m.keys)
                if next not in visited and no_enemies(next.pos, m.pos, g):
                    visited.append(next)
                    nextQueue.append(next)
                    from_node[to_string(next)] = m
                    if next.pos == sink and all(next.keys[:required]):
                        return get_path(start, next, from_node)

        roundQueue = nextQueue

        if len(nextQueue) == 0:
            print("Failed to find path!")
            exit(1)
        nextQueue = []
        g.step(0, 0)
        round = (round + 1) % 12


POS = 0x25
DIR = 6

ACTION_COUNT = 0

start = POS-1
dir = DIR
g = game.Game()

res = game.MAP
for i, k in enumerate(room_keys):
    res = game.apply_permutation(game.ROUNDS[i].key_to_perm[k], res)

assert res == [hex(i+1)[2:].upper().rjust(2, '0') for i in range(0x36)]

for ROUND in range(25):
    graph = generate_graph()
    map = [int(x, 16) for x in game.MAP]
    end = int(goal_rooms[ROUND], 16)-1

    keys = []
    key_len = 0
    if ROUND in pickup:
        key_len = len(pickup[ROUND])
        for r in game.ROUNDS[ROUND].key_rooms:
            if r[2:4] in pickup[ROUND]:
                keys.append(int(r[0:2], 16) - 1)

        if len(keys) != len(pickup[ROUND]):
            print("Oh no, double items?")
            exit(1)
    # if ROUND in pickup:
    #     for r in game.ROUNDS[ROUND].key_rooms:
    #         if r[2:4] not in pickup[ROUND]:
    #             keys.append(int(r[0:2], 16) - 1)

    # slow version checks if picking up unnecessary items can produce a smaller path but didn't find any
    # path = slow_bfs(graph, start, end, g, keys, key_len)
    path = bfs(graph, start, end, g, keys)
    ACTION_COUNT += len(path)-1

    room_to_id = {}
    for r in game.ROUNDS[ROUND].key_rooms:
        if ROUND in pickup and r[2:4] in pickup[ROUND]:
            if int(r[0:2], 16) in room_to_id:
                print("Multiple keys to pickup in one room")
                exit(1)
            room_to_id[int(r[0:2], 16)-1] = int(r[2:4], 16)

    actions = ""
    for i in range(len(path)-1):
        pos = path[i]
        next = path[i+1]

        if pos == next:
            actions += "pick up " + item_names[room_to_id[pos] - OFFSET] + '\n'
            continue
        if game.move(pos, dir) == next:
            actions += "go forward" + '\n'
            continue
        if game.move(pos, game.turnLeft(pos, dir)) == next:
            actions += "turn left" + '\n'
            dir = game.turnLeft(pos, dir)
            continue
        if game.move(pos, game.turnRight(pos, dir)) == next:
            actions += "turn right" + '\n'
            dir = game.turnRight(pos, dir)
            continue
        if game.move(pos, game.turnAround(dir)) == next:
            actions += "turn around" + '\n'
            dir = game.turnAround(dir)
            continue

        print("Prog error")
        print(hex(pos+1), dir, path)
        print(graph)
        exit(1)

    actions += "place " + item_names[int(room_keys[ROUND], 16) - OFFSET] + '\n'
    actions += room_keys[ROUND] + '\n'
    with open(f"real/move{ROUND}.txt", "w") as file:
        file.write(actions)

    print("Round:", ROUND, ", Actions:",
          ACTION_COUNT, [hex(i+1) for i in path])

    start = path[-1]

    old = game.MAP

    g.end_round(room_keys[ROUND])

    if ROUND < 24:
        dir = g.fixDirection(start, dir, room_keys[ROUND])


print("All done!")
