import time

print("Startup messages... This might take a couple of minutes...")

time.sleep(4)

print("Some output here afterwards")
inp = input("> ")

while inp != "give up":
    print("Game turn, then next input", inp)
    time.sleep(2)

    inp = input("> ")

print("done")
