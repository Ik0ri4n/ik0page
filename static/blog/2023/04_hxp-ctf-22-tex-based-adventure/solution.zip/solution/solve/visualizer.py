import igraph as ig
import matplotlib.pyplot as plt
plt.ion()


MAP = [
    "FFFFFFFFFFFFFFFF23090A2532280E0F0B11120D3310161713191A1534181E1F1B21221D35202627FFFFFFFFFFFFFFFFFF0C141C24FF",
    "FFFFFFFFFFFFFFFF0A0B1132140F1016121319331C17181E1A1B2134241F2026222309350C27280EFFFFFFFFFFFFFFFFFF0D151D25FF",
    "0431050608111213FFFFFFFFFFFFFFFF1433151618292A2BFFFFFFFFFFFFFFFF03020121232435252C362D2E3028272607FF17FF222F",
    "2322210103043105FFFFFFFFFFFFFFFF0607081113143315FFFFFFFFFFFFFFFF2435252628302F2E161718292B2C362D02FF12FF272A",
    "02031B311A070819010406090B0C320DFFFFFFFFFFFFFFFF1C341D1E202B2D30FFFFFFFFFFFFFFFF10292A0F360E2E2F050AFF1FFF2C",
    "0901020A310B06070C320D0E102E2C29FFFFFFFFFFFFFFFF080503191B1C341DFFFFFFFFFFFFFFFF2A2B1E361F2F3020040FFF1AFF2D"
]
for i in range(len(MAP)):
    text = MAP[i]
    MAP[i] = [text[2*p: 2*p+2] for p in range(len(text) // 2)]

ROUND = [hex(i)[2:].upper().rjust(2, '0') for i in range(1, 0x36+1)]

N_VERTICES = 0x36 + 18
REMOVED = [(13, 45), (14, 43), (15, 40), (47, 31), (44, 30),
           (42, 29), (39, 45), (38, 46), (37, 47)]
EXTRA = {}
EXTRA_COORDS = [(1, 5), (-7, 2), (0, 5), (-6, 2), (-1, 5), (-5, 2),
                (-7, -2), (1, -5), (-6, -2), (0, -5), (-5, -2), (-1, -5),
                (5, 1), (-8, 1), (5, 0), (-8, 0), (5, -1), (-8, -1)]


def move(pos: int, dir: int):
    inRound = ROUND.index(hex(pos+1)[2:].upper().rjust(2, '0'))
    index = MAP[dir-1][inRound]

    if index == "FF":
        return -1
    return int(ROUND[int(index, 16) - 1], 16)-1


def generate_edges():
    edges = []
    for node in range(0, 0x36):
        for dir in range(2, 8, 2):
            neighbor = move(node, dir)
            if neighbor != -1:
                edges.append((node, neighbor))

    extra = 0x36
    for e in REMOVED:
        edges.remove(e)

        edges.append((e[0], extra))
        EXTRA[extra] = e[1]
        extra += 1
        edges.append((e[1], extra))
        EXTRA[extra] = e[0]
        extra += 1

    # edges.remove((10, 16))#
    # edges.remove((12, 19))
    # edges.remove((15, 21))
    # edges.remove((18, 24))#
    # edges.remove((20, 27))
    # edges.remove((23, 29))
    # edges.remove((26, 32))#
    # edges.remove((28, 35))
    # edges.remove((31, 37))
    # edges.remove((34, 8))#
    # edges.remove((36, 11))
    # edges.remove((39, 13))

    return edges


def unmap(map: list[str], edges: list[tuple[int, int]]):
    map = [int(x, 16)-1 for x in map]

    res = []
    for e in edges:
        res.append((map.index(e[0]), map.index(e[1])))

    return res


class Visualizer:
    def __init__(self) -> None:
        self.edges = generate_edges()
        self.g = ig.Graph(N_VERTICES, self.edges)
        self.fig, self.ax = plt.subplots(figsize=(10, 10))

        coords = [(1, 1), (1, 0), (1, -1), (0, 1), (0, -1), (-1, 1), (-1, 0), (-1, -1),
                  (1, 2), (0, 2), (-1, 2), (1, 3), (-1, 3), (1, 4), (0, 4), (-1, 4),
                  (-2, 1), (-2, 0), (-2, -1), (-3,
                                               1), (-3, -1), (-4, 1), (-4, 0), (-4, -1),
                  (-1, -2), (0, -2), (1, -2), (-1, -
                                               3), (1, -3), (-1, -4), (0, -4), (1, -4),
                  (2, -1), (2, 0), (2, 1), (3, -1), (3, 1), (4, -1), (4, 0), (4, 1),
                  (-5, 1), (-5, 0), (-5, -1), (-6,
                                               1), (-6, -1), (-7, 1), (-7, 0), (-7, -1),
                  (0, 0), (0, 3), (-3, 0), (0, -3), (3, 0), (-6, 0)] + EXTRA_COORDS
        self.layout = ig.Layout(coords=coords)

    def draw(self, map: list[str], player_pos: int, next: int, encounters_at_pos: list[int], next_moves: list[tuple[int, int]]):
        remap = [0]*N_VERTICES
        for i in range(0x36):
            remap[i] = int(map[i], 16)-1
        for i in range(0x36, N_VERTICES):
            remap[i] = remap[EXTRA[i]]

        labels = map + [""]*18
        for i in range(0x36, N_VERTICES):
            labels[i] = labels[EXTRA[i]]

        vertex_color = ["blue" if remap[n] == player_pos else "red" if encounters_at_pos[remap[n]] > 0 else "gray" for n in range(N_VERTICES)]

        next_moves = unmap(map, next_moves)
        edge_color = ["gray"] * len(self.edges)
        for move in next_moves:
            if move in self.edges:
                edge_color[self.edges.index(move)] = "orangeRed"
            if move in REMOVED:
                ind = REMOVED.index(move)
                edge_color[len(self.edges) - 18 + 2*ind] = "orangeRed"
                edge_color[len(self.edges) - 18 + 2*ind + 1] = "orangeRed"
            inverse = (move[1], move[0])
            if inverse in self.edges:
                edge_color[self.edges.index(inverse)] = "orangeRed"
            if inverse in REMOVED:
                ind = REMOVED.index(inverse)
                edge_color[len(self.edges) - 18 + 2*ind] = "orangeRed"
                edge_color[len(self.edges) - 18 + 2*ind + 1] = "orangeRed"

        map = [int(x, 16)-1 for x in map]
        player_move = (map.index(player_pos), map.index(next))
        if player_move in self.edges:
            edge_color[self.edges.index(player_move)] = "green"
        if player_move in REMOVED:
            ind = REMOVED.index(player_move)
            edge_color[len(self.edges) - 18 + 2*ind] = "green"
            edge_color[len(self.edges) - 18 + 2*ind + 1] = "green"
        inverse = (player_move[1], player_move[0])
        if inverse in self.edges:
            edge_color[self.edges.index(inverse)] = "green"
        if inverse in REMOVED:
            ind = REMOVED.index(inverse)
            edge_color[len(self.edges) - 18 + 2*ind] = "green"
            edge_color[len(self.edges) - 18 + 2*ind + 1] = "green"

        self.ax.clear()
        ig.plot(self.g, target=self.ax, layout=self.layout,
                vertex_color=vertex_color, vertex_label=labels, vertex_label_angle=0.785, vertex_label_dist=1, edge_color=edge_color) # TODO: spacing of labels
        plt.draw()

    def pause(self, time: int):
        plt.pause(time)

    def show(self):
        plt.show()
    pass
