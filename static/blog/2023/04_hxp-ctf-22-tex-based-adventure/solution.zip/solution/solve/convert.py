class Tree:
    def should_indent(self) -> bool:
        return False


class Root(Tree):

    def __init__(self, children: list[Tree]) -> None:
        self.children = children

    def should_indent(self) -> bool:
        return False

    def __repr__(self) -> str:
        return repr(self.children)

    def __str__(self) -> str:
        return "\n".join([str(child) for child in self.children])


class Fragment(Tree):
    def __init__(self, text: str) -> None:
        self.text = text

    def __repr__(self) -> str:
        return repr(self.text)

    def __str__(self) -> str:
        return self.text

    def should_indent(self) -> bool:
        return "\\" in self.text


class Block(Tree):
    def __init__(self, children: list[Tree]) -> None:
        self.children = children

    def __repr__(self) -> str:
        return repr(self.children)

    def __str__(self) -> str:
        result = "{"
        if self.should_indent():
            children = "\n".join([str(child) for child in self.children])
            children = "\n".join(["  " + x for x in children.splitlines()])
            result += f"\n{children}\n"
        else:
            result += "".join([str(child) for child in self.children])
        result += "}"
        return result

    def should_indent(self) -> bool:
        return any([x.should_indent() for x in self.children])


def parse_fragment(text: str) -> tuple[Fragment, str]:
    assert text[0] != "{"
    end: int = 100000000
    if "{" in text:
        end = text.index("{")
    if "}" in text:
        end = min(end, text.index("}"))

    return (Fragment(text[0:end]), text[end:])


def parse_block(text: str) -> tuple[Block, str]:
    assert text[0] == "{"
    text = text[1:]

    children: list[Tree] = []

    while text[0] != "}":
        (child, rest) = parse_block_or_fragment(text)
        children.append(child)
        text = rest

    assert text[0] == "}"
    text = text[1:]

    return (Block(children), text)


def parse_block_or_fragment(text: str) -> tuple[Tree, str]:
    if text[0] == "{":
        return parse_block(text)
    return parse_fragment(text)


def parse_latex(text: str) -> tuple[Root, str]:
    (block, rest) = parse_block("{" + text + "}")
    return (Root(block.children), rest)


def first_stage() -> str:
    content = ""
    with open("first_stage.input", "r") as file:
        text = file.read()

        for char in text:
            if char in {"\n", "\r", " ", "\t"}:
                content+=char
                continue
            decoded_char = chr(32 + (ord(char) + 71) % 96)
            content += decoded_char

    (root, rest) = parse_latex(content)
    result = r"""
    #!/usr/bin/pdflatex \batchmode \catcode35=14 \input
    \catcode`\#=6
    \documentclass[multi=frame]{standalone}

    \ExplSyntaxOn
    """.strip()

    return f"{result}\n\n{str(root)}"


if __name__ == "__main__":
    # print(parse_latex("{A}{B}{CD{EF}GH}"))
    # print(str(parse_latex("{A}{B}{CD{E\\fooF}GH}")[0]))
    print(first_stage())
