import game


SOLUTION = []
SOLUTION_KEYS = []

for i, r in enumerate(game.ROUNDS):
    if i == len(game.ROUNDS)-1:
        break

    rooms = []
    for l in r.lock_rooms:
        rooms.append(l[0:2])

    for e in game.ROUNDS[i+1].encounters:
        blocked = e[0:2]
        if blocked in rooms:
            rooms.remove(blocked)

    if len(rooms) > 1:
        exit(1)

    SOLUTION.append(rooms[0])
    for l in r.lock_rooms:
        if l[0:2] == rooms[0]:
            SOLUTION_KEYS.append(l[2:4])

SOLUTION.append(game.ROUNDS[-1].lock_rooms[0][0:2])
SOLUTION_KEYS.append(game.ROUNDS[-1].lock_rooms[0][2:4])


def check_keys(available_keys: dict[str, int], chain: list[str], encounters: list[str], key_items: list[str], lock_rooms: list[str], lock: str):
    for e in encounters:
        if e[2:4] == "00":
            blocked = e[0:2]
            for k in key_items:
                if k[0:2] == blocked:
                    key_items.remove(k)
            for l in lock_rooms:
                if l[0:2] == blocked:
                    lock_rooms.remove(l)
    gathered = []
    for k in key_items:
        key = k[2:4]

        if key not in chain:
            continue

        gathered.append(key)
        if key in available_keys:
            available_keys[key] += 1
        else:
            available_keys[key] = 1

    available_keys[lock] -= 1

    return (available_keys, gathered)


available_keys = {}
gathered = {}
count = 0
for i in range(len(SOLUTION_KEYS)):
    r = game.ROUNDS[i]
    lock = SOLUTION_KEYS[i]

    (available_keys, g) = check_keys(available_keys,
                                     SOLUTION_KEYS[i:], r.encounters, r.key_rooms, r.lock_rooms, lock)

    if available_keys[lock] < 0:
        print("Not usable!")
        break

    if len(g) > 0:
        count += len(g)
        gathered[i] = g

print(SOLUTION)
print(SOLUTION_KEYS)
print(gathered)
