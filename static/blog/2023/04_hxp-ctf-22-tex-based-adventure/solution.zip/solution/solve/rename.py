import requests
from pathlib import Path
import sys


def get_renames() -> tuple[list[tuple[str, str]], list[tuple[str, str]]]:
    text: str = requests.get("<HedgeDoc url>").text
    literals: list[tuple[str, str]] = []
    methods: list[tuple[str, str]] = []
    for line in text.splitlines():
        parts = line.split(" ")
        if line.startswith('#') or len(parts) != 2:
            print("Ignoring: ", repr(line), "parts:", repr(parts))
            continue

        if line.startswith('!'):
            literals.append((parts[0][1:], parts[1]))
        else:
            methods.append((parts[0], parts[1]))
    return (literals, methods)


def apply_renames(target_file: Path):
    (literals, methods) = get_renames()

    print(literals)
    print(methods)
    with open(target_file, "r") as file:
        content = file.read()
        for (src, dest) in literals:
            content = content.replace(src, dest)
            print("Replacing", src, "with", dest)
        for (src, dest) in methods:
            content = content.replace("hxp_" + src, "hxp_" + dest)
            print("Replacing", "hxp_" + src, "with", "hxp_" + dest)

    with open(target_file, "w") as file:
        file.write(content)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <target file>")
        exit(1)
    res = Path(sys.argv[1])
    if not res.exists():
        print(f"File {res} not found")
        exit(1)
    apply_renames(res)