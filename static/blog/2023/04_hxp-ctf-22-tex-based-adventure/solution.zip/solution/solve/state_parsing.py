import base64
from io import BytesIO
from pypdf import PdfReader, PdfWriter
import re

from typing_extensions import Literal


DEBUG = True


GLOBALS = {}
BLOCKS = ""


def prop_item(g_key: str, key: str):
    return GLOBALS[g_key][key]


def prop_gremove(g_key: str, key: str):
    GLOBALS[g_key].pop(key)


def clist_gput_right(key: str, value: str):
    if key in GLOBALS:
        GLOBALS[key] += "," + value
    else:
        GLOBALS[key] = value


def prop_gput(g_key, key, value):
    if g_key not in GLOBALS:
        GLOBALS[g_key] = {}
    GLOBALS[g_key][key] = value


def debug(*values: object,
          sep: str | None = " ",
          end: str | None = "\n",
          file,
          flush: Literal[False] = False,):
    if DEBUG:
        print(values, sep, end, file, flush)


def dict_fromStr(dict: str):
    result = {}
    pairs = re.findall(r"([a-zA-Z0-9_]+)=([a-zA-Z0-9_~{}\[\],-]+),", dict)
    for (key, val) in pairs:
        result[key] = val
    return result


def global_setOrInit(key: str, dict: str):
    if key in GLOBALS:
        GLOBALS[key].update(dict_fromStr(dict))
    else:
        GLOBALS[key] = dict_fromStr(dict + "rzVB={},kyHu={},iDNQ=1,")


def before_comma(value: str) -> str:
    pos = value.find(",")
    if pos == -1:
        return ""
    return value[:pos]


def after_comma(value: str) -> str:
    pos = value.find(",")
    if pos == -1:
        return ""
    return value[pos+1:]


def base64_decodeToHex(value: str) -> str:
    decoded: bytes = base64.decodebytes(value.encode())
    result = "".join([hex(b)[2:].zfill(2).upper() for b in decoded])
    return result


def parseP1_convertAndContinue(start: int, name: str, value: str, length: int, fun1, fun2) -> str:
    result = name + "=" + \
        fun1(value[start - 1: start + length - 1]) + "," + fun2(start + length)
    return result


def parseP1_readLenAndContinue(start: int, name: str, value: str, length: int, fun1, fun2) -> str:
    result = name + "=" + \
        parseP1_convertWithLenAndContinue(int(value[start-1: start+length-1], 16),
                                          start+length, value, fun1, fun2)
    return result


def parseP1_convertWithLenAndContinue(length: int, start: int, value: str, fun1, fun2) -> str:
    result = fun1(value[start-1: start + length*2 - 1]) + \
        "," + fun2(start + length*2)
    return result


def parseP1_convertRemainder(start: int, name: str, value: str, fun1) -> str:
    result = name + "=" + fun1(value[start-1:]) + ","
    return result


def to_chars(value: str) -> str:
    if value == "":
        return ""

    # WARNING: implemented without recursion
    return "".join([chr(int(value[2*i: 2*i+2], 16)) for i in range(len(value) // 2)])


def to_char(value: int):
    if value == 126:
        return " "
    else:
        return chr(value)  # TODO: c_code


def use(value: str):
    return value


def hexValAtPos(hex_val: str, pos: int):
    pos -= 1
    return hex_val[2*pos:2*pos+2]


def parseRemainingPdfObjects(value: str):
    if value != "":
        parsePdfKey(int(hexValAtPos(value, 1), 16), value)
        pass


def parsePdfKey(num: int, value: str):
    # print("f2", num)
    parsePdfWidthAndHeight(hexStringToChars(value[2: 2*num+2]),
                           value[2*num+2:])
    pass


def hexStringToChars(value: str):
    return "".join([chr(int(value[2*i:2*i+2], 16)) for i in range(len(value) // 2)])


def parsePdfWidthAndHeight(key: str, value: str):
    # print("f4", key)
    separateCurrentPdfAndRemainder(
        int(value[0: 4], 16), int(value[4: 8], 16), key, value)
    pass


def separateCurrentPdfAndRemainder(width: int, height: int, key: str, value: str):
    # print("f5", num1, num2, key)
    setPdfValsAndContinue(value[8: 8 + 6*width*height],
                          value[8 + 6*width*height:], width, height, key)
    pass


def setPdfValsAndContinue(value: str, remainder: str, width: int, height: int, key: str):
    # print("f6", width, height, key)
    setPdfGlobals(key, width, height, value)
    parseRemainingPdfObjects(remainder)
    pass


def setPdfGlobals(key: str, width: int, height: int, value: str):
    # print("f7", key, num2, num3)
    clist_gput_right("hxp_jhiw", key)
    prop_gput("hxp_gHdJ", key, str(width) + " "+str(height))
    prop_gput("hxp_BoZH", key, value)
    writeNewPdfObject(key, width, height, hexStringToChars(value))
    pass


def writeNewPdfObject(key: str, width: int, height: int, value: str):
    # print(key, width, height)
    # with open(f"pdfs/pdf_object_{key}.pdf", "wb") as file:
    #     writer:PdfWriter = PdfWriter()
    #     writer.add_metadata({"/Type/XObject/Subtype/Image/Width": str(width),
    #                         "/Height": str(height),
    #                         "/ColorSpace/DeviceRGB/BitsPerComponent": str(8)})
    #     bytesStream = BytesIO(value.encode()+b"\r\n%%EOF")
    #     reader = PdfReader(bytesStream)
    #     writer.append_pages_from_reader(reader)
    #     writer.write(file)

    pass


def parse_first_block(g_game_state: str, hex_data: str):
    tmp = parseP1_convertAndContinue(1, "EdWg", hex_data, 96, use, lambda start:
                                     parseP1_convertAndContinue(start, "MrzK", hex_data, 4, use, lambda start:
                                                                parseP1_convertAndContinue(start, "state_loop_condition_upper", hex_data, 4, lambda s: str(int(s, 16)), lambda start:
                                                                                           parseP1_readLenAndContinue(start, "VljH", hex_data, 4, to_chars, lambda start:
                                                                                                                      parseP1_convertRemainder(start, "bxFX", hex_data, use)))))
    global_setOrInit(g_game_state, tmp)

    parseRemainingPdfObjects(prop_item(g_game_state, "bxFX"))
    prop_gremove(g_game_state, "bxFX")
    pass


def parseP2_convertWithLenAndContinue(start: int, name: str, value: str, length: int, num: int, fun1, fun2) -> str:
    result = name + "=" + \
        parseP2_convertAndContinue(int(value[start-1: start+length-1], 16),
                                   start+length, value, num, fun1, fun2)
    return result


def parseP2_convertAndContinue(num1: int, start: int, value: str, num2: int, fun1, fun2):
    result = parseP2_convertListLoop(num1, num1, start, value, num2, fun1) + \
        "," + fun2(start + num1*num2)
    return result


def parseP2_convertListLoop(countDown: int, total: int, start: int, value: str, size: int, fun1):
    if value == "":
        ""

    result = fun1(value[start + (total - countDown)*size -
                  1:start + (total - countDown+1)*size-1])
    while countDown > 1:
        countDown -= 1
        result += "," + \
            fun1(value[start + (total - countDown)*size -
                 1:start + (total - countDown+1)*size-1])
    return result


def parse_block(value: str):
    result = parseP2_convertWithLenAndContinue(1, "qwsI", value, 2, 6, use, lambda start:
                                               parseP2_convertWithLenAndContinue(start, "NHmX", value, 2, 4, use, lambda start:
                                                                                 parseP2_convertWithLenAndContinue(start, "vpAZ", value, 2, 6, use, lambda start:
                                                                                                                   parseP1_convertRemainder(start, "nOTa", value, use))))

    return result


def parse_block_update_state(g_game_state: str, hex_value: str):
    global BLOCKS
    block = parse_block(hex_value)
    BLOCKS += block
    global_setOrInit(g_game_state, block)


def assert_globalsInitialized(g_game_state: str):
    if "hxp_parsing_remainder" not in GLOBALS[g_game_state]:
        print("Internal error. Please try again.")
        print(1)
        exit(-1)
    if "EdWg" not in GLOBALS[g_game_state]:
        print("Internal error. Please try again.")
        print(2)
        exit(-1)
    if "VljH" not in GLOBALS[g_game_state]:
        print("Internal error. Please try again.")
        print(3)
        exit(-1)
    if "MrzK" not in GLOBALS[g_game_state]:
        print("Internal error. Please try again.")
        print(4)
        exit(-1)
    if "qwsI" not in GLOBALS[g_game_state]:
        print("Internal error. Please try again.")
        print(5)
        exit(-1)
    if "NHmX" not in GLOBALS[g_game_state]:
        print("Internal error. Please try again.")
        print(6)
        exit(-1)
    if "vpAZ" not in GLOBALS[g_game_state]:
        print("Internal error. Please try again.")
        print(7)
        exit(-1)
    if "state_loop_condition_upper" not in GLOBALS[g_game_state]:
        print("Internal error. Please try again.")
        print(8)
        exit(-1)


def parse_one_block(g_game_state: str, block: str):
    if block == "":
        return

    parse_block_update_state(g_game_state, base64_decodeToHex(block))

    # TODO: some cctab reset of the then deleted var
    print(hexStringToChars(prop_item(g_game_state, "nOTa")))
    prop_gremove(g_game_state, "nOTa")

    assert_globalsInitialized(g_game_state)
    pass


def parse_game_state(g_game_state: str, input: str):
    part = base64_decodeToHex(before_comma(input))
    parse_first_block(g_game_state, part)

    prop_gput(g_game_state, "hxp_parsing_remainder", after_comma(input))

    parse_one_block(g_game_state, before_comma(
        prop_item(g_game_state, "hxp_parsing_remainder")))

    print(GLOBALS)


if __name__ == "__main__":
    with open("game_state.input", "r") as file:
        input = file.read()  # .replace("\n", "")
    
    parse_game_state("hxp_game_state", input)

    remainder = GLOBALS["hxp_game_state"]["hxp_parsing_remainder"]
    for block in remainder.split(','):
        BLOCKS += "\n" + parse_block(base64_decodeToHex(block))
    
    with open("blocks.txt", "w") as file:
        file.write(BLOCKS)
