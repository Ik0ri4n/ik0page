from collections import namedtuple
import re

LEN = 48
CONSTANTS = {
    "hxp_JTvy": "03050802070104062122230000000000090A0B00000000001112130000000000191A1B00000000000000000000000000",
    "hxp_Hlpc": "0000000000000000000000000016171800000000001E1F20000000000026272800000000000E0F102B2D302A2F292C2E",
    "hxp_iQCG": "0000260024000021000000000000000000000300050000081B1D201A1F191C1E3000002D002B00000000130015000018",
    "hxp_NJPW": "11000014001600000B0D100A0F090C0E2900002C002E0000000000000000000000000600040000012800002500230000",
    "hxp_ytua": "0000000000191C1E000008000700000613151812171114162B00002A0029000000000000000000000B0D100000000000",
    "hxp_QjbB": "0E0C0900000000002E00002F003000000000000000000000000001000200000323252822272124260000000000201D1B",
}
PERM_POS = {
    "hxp_JTvy": 0,
    "hxp_Hlpc": 1,
    "hxp_iQCG": 2,
    "hxp_NJPW": 3,
    "hxp_ytua": 4,
    "hxp_QjbB": 5,
}

PERMUTATIONS = {}
for (key, val) in CONSTANTS.items():
    perm = {}
    for i in range(LEN):
        from_pos = int(val[2*i: 2*i+2], 16)

        if from_pos == 0:
            perm[i] = i
        else:
            perm[i] = from_pos-1

    PERMUTATIONS[key] = perm


def apply_permutation(key: str, vals: list[str]) -> list[str]:
    out = [0]*len(vals)
    p = PERMUTATIONS[key]

    for i in range(LEN):
        out[i] = vals[p[i]]
    for i in range(LEN, len(vals)):
        out[i] = vals[i]
    return out


Round = namedtuple("Round", "encounters key_rooms lock_rooms key_to_perm")

with open("blocks.txt", "r") as file:
    text = file.read()

blocks = text.split("\n")
ROUNDS: list[Round] = []
for b in blocks:
    match = re.match(r"qwsI=(.+),NHmX=(.+),vpAZ=(.+),nOTa=(.+),", b)
    (encounters, key_rooms, lock_rooms, code) = match.groups()
    encounters = encounters.split(',')
    key_rooms = key_rooms.split(',')
    lock_rooms = lock_rooms.split(',')
    code = "".join([chr(int(code[2*i: 2*i+2], 16))
                   for i in range(len(code) // 2)])

    matches = re.findall(
        r"\{([0-9A-F]{2})\}\{\\hxp_UFaA:NN#1\\([a-zA-Z_]+)\}", code)

    key_to_perm = {}
    for (key, perm_key) in matches:
        key_to_perm[key] = perm_key

    r = Round(encounters, key_rooms, lock_rooms, key_to_perm)

    ROUNDS.append(r)

AXES = [
    "FFFFFFFFFFFFFFFF23090A2532280E0F0B11120D3310161713191A1534181E1F1B21221D35202627FFFFFFFFFFFFFFFFFF0C141C24FF",
    "FFFFFFFFFFFFFFFF0A0B1132140F1016121319331C17181E1A1B2134241F2026222309350C27280EFFFFFFFFFFFFFFFFFF0D151D25FF",
    "0431050608111213FFFFFFFFFFFFFFFF1433151618292A2BFFFFFFFFFFFFFFFF03020121232435252C362D2E3028272607FF17FF222F",
    "2322210103043105FFFFFFFFFFFFFFFF0607081113143315FFFFFFFFFFFFFFFF2435252628302F2E161718292B2C362D02FF12FF272A",
    "02031B311A070819010406090B0C320DFFFFFFFFFFFFFFFF1C341D1E202B2D30FFFFFFFFFFFFFFFF10292A0F360E2E2F050AFF1FFF2C",
    "0901020A310B06070C320D0E102E2C29FFFFFFFFFFFFFFFF080503191B1C341DFFFFFFFFFFFFFFFF2A2B1E361F2F3020040FFF1AFF2D"
]
for i in range(len(AXES)):
    text = AXES[i]
    AXES[i] = [text[2*p: 2*p+2] for p in range(len(text) // 2)]


TURN_OFFSET = "000000000000000006060606060606060C0C0C0C0C0C0C0C121212121212121218181818181818181E1E1E1E1E1E1E1E00060C12181E"
TURN_OFFSET = [TURN_OFFSET[2*p: 2*p+2] for p in range(len(TURN_OFFSET) // 2)]
LEFT_TURNS = "FFFF050604030605FFFF010203040201FFFF0506FFFF020104030102FFFFFFFF06050304"
LEFT_TURNS = [LEFT_TURNS[2*p: 2*p+2] for p in range(len(LEFT_TURNS) // 2)]
RIGHT_TURNS = "FFFF060503040506FFFF020104030102FFFF0605FFFF010203040201FFFFFFFF05060403"
RIGHT_TURNS = [RIGHT_TURNS[2*p: 2*p+2] for p in range(len(RIGHT_TURNS) // 2)]


MAP = "1607130C272B040329251E2D1A230230180A1B0517200F11212F192A240B15280812101D1F0E1409262C06221C010D2E313233343536"
MAP = [MAP[2*p: 2*p+2] for p in range(len(MAP) // 2)]

INITIAL_POS = 0x25-1
INITIAL_DIR = 6


def move(pos: int, dir: int):
    inRound = MAP.index(hex(pos+1)[2:].upper().rjust(2, '0'))

    if dir < 1 or dir > 6 or inRound < 0 or inRound >= len(AXES[0]):
        print(pos, dir, inRound)
        return -1
    index = AXES[dir-1][inRound]

    if index == "FF":
        # print(pos, dir)
        return -1
    return int(MAP[int(index, 16) - 1], 16)-1


def turnLeft(pos: int, dir: int):
    inRound = MAP.index(hex(pos+1)[2:].upper().rjust(2, '0'))
    new = int(LEFT_TURNS[dir + int(TURN_OFFSET[inRound], 16) - 1], 16)

    if new < 1 or new > 6:
        print("left", pos, dir, new)
        return -1
    return new


def turnRight(pos: int, dir: int):
    inRound = MAP.index(hex(pos+1)[2:].upper().rjust(2, '0'))
    new = int(RIGHT_TURNS[dir + int(TURN_OFFSET[inRound], 16) - 1], 16)

    if new < 1 or new > 6:
        print("right", pos, dir, new)
        return -1
    return new


def turnAround(dir: int):
    if dir % 2 == 0:
        return dir - 1
    else:
        return dir + 1


class Encounter:
    def __init__(self, pos: int, dir: int, id: int) -> None:
        self.pos = pos
        self.last_pos = pos
        self.dir = dir
        self.id = id

    def move(self):
        if self.dir != 0:
            self.last_pos = self.pos
            self.pos = move(self.pos, self.dir)


class Game:
    def __init__(self, keys=[], pos=INITIAL_POS, dir=INITIAL_DIR) -> None:
        global MAP, ROUNDS
        self.round = len(keys)

        self.player_pos = pos
        self.player_dir = dir
        self.old_map = MAP

        for round, key in enumerate(keys):
            perm_key = ROUNDS[round].key_to_perm[key]
            MAP = apply_permutation(perm_key, MAP)

        self.encounters = [Encounter(int(e[0:2], 16)-1, int(e[2:4], 16), e[4:6])
                           for e in ROUNDS[self.round].encounters]

        self.encounters_at_pos = [0] * 0x36
        self.encounters_map: list[list[Encounter]] = [[]] * 0x36
        self.encounters_next_moves = []
        for e in self.encounters:
            self.encounters_at_pos[e.pos] += 1

            if len(self.encounters_map[e.pos]) == 0:
                self.encounters_map[e.pos] = [e]
            else:
                self.encounters_map[e.pos].append(e)
            if e.dir != 0:
                self.encounters_next_moves.append((e.pos, move(e.pos, e.dir)))

    def step(self, pos: int, dir: int):
        self.player_pos = pos
        self.player_dir = dir

        self.encounters_next_moves = []
        self.encounters_map = [[]] * 0x36
        for e in self.encounters:
            self.encounters_at_pos[e.pos] -= 1
            e.move()
            self.encounters_at_pos[e.pos] += 1

            if len(self.encounters_map[e.pos]) == 0:
                self.encounters_map[e.pos] = [e]
            else:
                self.encounters_map[e.pos].append(e)

            if e.dir != 0:
                self.encounters_next_moves.append(
                    (e.pos, move(e.pos, e.dir)))

    def end_round(self, key: str):
        global MAP, ROUNDS

        self.old_map = MAP

        perm_key = ROUNDS[self.round].key_to_perm[key]
        MAP = apply_permutation(perm_key, MAP)
        # print(MAP)
        self.round += 1

        if self.round < 25:
            self.player_dir = self.fixDirection(
                self.player_pos, self.player_dir, key)

            self.encounters = [Encounter(int(e[0:2], 16)-1, int(e[2:4], 16), e[4:6])
                               for e in ROUNDS[self.round].encounters]

            self.encounters_at_pos = [0] * 0x36
            self.encounters_map = [[]] * 0x36
            self.encounters_next_moves = []
            for e in self.encounters:
                self.encounters_at_pos[e.pos] += 1

                if len(self.encounters_map[e.pos]) == 0:
                    self.encounters_map[e.pos] = [e]
                else:
                    self.encounters_map[e.pos].append(e)

                if e.dir != 0:
                    self.encounters_next_moves.append(
                        (e.pos, move(e.pos, e.dir)))

    def fixDirection(self, pos: int, dir: int, key: str) -> int:
        changed = []
        for i in range(len(MAP)):
            if self.old_map[i] != MAP[i]:
                changed += [self.old_map[i]]

        perm_key = ROUNDS[self.round - 1].key_to_perm[key]
        changed += [["31", "36", "34", "32", "33", "35"][PERM_POS[perm_key]]]

        if hex(pos + 1)[2:].upper().rjust(2, '0') in changed:
            inRound = [0x31, 0x36, 0x34, 0x32, 0x33, 0x35][PERM_POS[perm_key]]
            new = LEFT_TURNS[dir + int(TURN_OFFSET[inRound-1], 16) - 1]
            if new != 'FF':
                dir = int(new, 16)

        return dir
