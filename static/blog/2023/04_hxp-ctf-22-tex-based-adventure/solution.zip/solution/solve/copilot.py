import pwn


RUN_CMD = "docker run -i tb-adventure"
# RUN_CMD = "python temp.py"
CONTROLLER_CMD = "python controller.py"

LOG = ""
ROUND = 0

print("Start loading latex process. Please be patient!")
with pwn.process(RUN_CMD, shell=True) as proc:
    with pwn.process(CONTROLLER_CMD, shell=True) as control:
        out = proc.recvuntil(b"This might take a couple of minutes...").decode()
        print(out)
        LOG += out
        out = proc.recvuntil(b"> ").decode()
        print(out)
        LOG += out
        control.recvuntil(b"SHOW").decode()
        

        inp = input()[:-1]
        while inp != "STOP" and inp != "give up":
            if inp == "LOAD":
                with open(f"real/move{ROUND}.txt", "r") as file:
                    lines = file.readlines()
                
                for line in lines:
                    line = line[:-1]
                    LOG += line + '\n'
                    print(line)

                    proc.sendline(line.encode())
                    control.sendline(line.encode())


                    if line.startswith("place"):
                        with open(f"log.txt", "w") as file:
                            file.write(LOG)

                        key = lines[-1][:-1]
                        control.sendline(key.encode())
                        ROUND += 1
                        break

                    out = proc.recvuntil(b"> ").decode()
                    print(out)
                    LOG += out
                    control.recvuntil(b"SHOW").decode()
                

                out = proc.recvuntil(b"> ").decode()
                print(out)
                LOG += out
                control.recvuntil(b"SHOW").decode()

                inp = input()[:-1]
                continue


            LOG += inp + '\n'
            proc.sendline(inp.encode())
            control.sendline(inp.encode())

            if inp.startswith("place"):
                with open(f"log.txt", "w") as file:
                    file.write(LOG)

                key = input("Key: ")[:-1]
                control.sendline(key.encode())
                ROUND += 1

            out = proc.recvuntil(b"> ").decode()
            print(out)
            LOG += out
            control.recvuntil(b"SHOW").decode()

            inp = input()[:-1]


with open(f"log.txt", "w") as file:
    file.write(LOG)
