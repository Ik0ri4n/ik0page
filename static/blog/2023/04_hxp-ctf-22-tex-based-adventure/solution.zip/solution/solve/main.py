import pwn


RUN_CMD = "docker run -i tb-adventure"
# RUN_CMD = "python temp.py"

LOG = ""
ROUND = 0

print("Start loading latex process. Please be patient!")
with pwn.process(RUN_CMD, shell=True) as proc:
    out = proc.recvuntil(b"This might take a couple of minutes...").decode()
    print(out)
    LOG += out
    out = proc.recvuntil(b"> ").decode()
    print(out)
    LOG += out
    
    input()
    for r in range(25):
        with open(f"real/move{ROUND}.txt", "r") as file:
            lines = file.readlines()
        
        for line in lines:
            line = line[:-1]
            LOG += line + '\n'
            print(line)

            proc.sendline(line.encode())


            if line.startswith("place"):
                with open(f"log.txt", "w") as file:
                    file.write(LOG)

                ROUND += 1
                break

            out = proc.recvuntil(b"> ").decode()
            print(out)
            LOG += out
        
        if r < 24:
            out = proc.recvuntil(b"> ").decode()
            print(out)
            LOG += out
            # exit(0)
        else:
            proc.interactive()


with open(f"log.txt", "w") as file:
    file.write(LOG)
