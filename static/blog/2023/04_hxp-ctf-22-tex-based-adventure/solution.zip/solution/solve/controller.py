import game
import visualizer


MOVES = ""
folder = "manual"


g = game.Game()
vis = visualizer.Visualizer()

vis.draw(game.MAP, g.player_pos, game.move(g.player_pos, g.player_dir),
         g.encounters_at_pos, g.encounters_next_moves)
vis.pause(1)
print("SHOW")

inp = input()
if inp == "SIM":
    folder = "sim"
    keys = input("KEYS: ").split(' ')
    pos = int(input("Pos: "), 16)-1
    dir = int(input("Dir: "), 16)

    g = game.Game(keys, pos, dir)
    vis.draw(game.MAP, g.player_pos, game.move(g.player_pos,
             g.player_dir), g.encounters_at_pos, g.encounters_next_moves)
    vis.pause(1)

    inp = input()

while inp != "STOP":
    pos = g.player_pos
    dir = g.player_dir

    MOVES += inp + '\n'

    if inp == "turn left":
        dir = game.turnLeft(pos, dir)
        pos = game.move(pos, dir)
    if inp == "turn right":
        dir = game.turnRight(pos, dir)
        pos = game.move(pos, dir)
    if inp == "turn around":
        dir = game.turnAround(dir)
        pos = game.move(pos, dir)
    if inp == "go forward":
        pos = game.move(pos, dir)
    if inp.startswith("place"):
        key = input("Key: ")

        MOVES += key + "\n"
        with open(f"{folder}/move{str(g.round)}.txt", "w") as file:
            file.write(MOVES)
        MOVES = ""

        g.end_round(key)
        vis.draw(game.MAP, g.player_pos, game.move(g.player_pos,
                 g.player_dir), g.encounters_at_pos, g.encounters_next_moves)
        vis.pause(1)
        print("SHOW")

        inp = input()
        continue

    g.step(pos, dir)
    vis.draw(game.MAP, g.player_pos, game.move(g.player_pos,
             g.player_dir), g.encounters_at_pos, g.encounters_next_moves)
    vis.pause(1)
    print("SHOW")

    inp = input()
