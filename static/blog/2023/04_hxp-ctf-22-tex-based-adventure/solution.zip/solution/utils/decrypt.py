with open("first_stage.input", "r") as file:
    content = ""
    text = file.read()

    for char in text:
        if char in {"\n", "\r", "\t"}:
            content+=char
            continue
        decoded_char = chr(32 + (ord(char) + 71) % 96)
        content += decoded_char

with open("modified.tex", "w") as file:
    file.write(content)