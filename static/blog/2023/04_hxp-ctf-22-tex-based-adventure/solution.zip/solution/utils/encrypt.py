with open("modified.tex", "r") as file:
    content = ""
    text = file.read()

    for char in text:
        if char in {"\n", "\r", "\t"}:
            content += char
            continue
        # print(char)
        if ord(char)-32 < 7:
            decoded_char = chr(ord(char)+96-7)
        else:
            decoded_char = chr(ord(char)-7)
        content += decoded_char

with open("modified.out", "w") as file:
    file.write(content)


# with open("first_stage.input") as file:
#     content = file.read()

#     minimum = 1000
#     maximum = 0
#     for char in content:
#         if char in {"\n", "\r", " ", "\t"}:
#             continue

#         minimum = min(ord(char), minimum)
#         maximum = max(ord(char), maximum)

# print(minimum, maximum)

# real = ""
# rev = ""
# for i in range(32, 125):
#     real += chr(i)
#     char = chr(32 + (i + 71) % 96)
#     if ord(char)-32 < 7:
#         decoded_char = chr(ord(char)+96-7)
#     else:
#         decoded_char = chr(ord(char)-7)
#     rev+= decoded_char

# print(real)
# print(rev)
