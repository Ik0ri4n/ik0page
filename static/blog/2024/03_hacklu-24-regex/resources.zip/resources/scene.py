from collections import deque
import math
from typing import Callable, Iterable, Sequence
from manim import *

from solver import WALL, generate_blocks, restore_program

# WARNING: HERE BE DRAGONS 
#
# The following code contains a lot of hacky solutions for a very specific use case.
# Please see Manims Docs for clean examples: https://docs.manim.community/en/stable/examples.html
#
# That being said, you can adjust the challenge at the top and the config at the bottom to generate custom videos.
# Prompts langer than the long example below will likely not fit well onto the screen.

CHALLENGE = "XfoRu0RDx2LU2" # Example used in post
# CHALLENGE = "PYx4fV3XXe0Hdd37jwWD6wI6FSu0K8jyBL3" # Longer example

class Grid(Table):
    def __init__(
        self,
        table: Iterable[Iterable[float | str | VMobject]],
        row_labels: Iterable[VMobject] | None = None,
        col_labels: Iterable[VMobject] | None = None,
        top_left_entry: VMobject | None = None,
        v_buff: float = 0.3,
        h_buff: float = 0.6,
        include_outer_lines: bool = False,
        add_background_rectangles_to_entries: bool = False,
        entries_background_color: ParsableManimColor = BLACK,
        include_background_rectangle: bool = False,
        background_rectangle_color: ParsableManimColor = BLACK,
        element_to_mobject: Callable[
            [str | None],
            VMobject,
        ] = lambda x: VGroup(  # Hacky hotfix to block size
            Paragraph("|", color=BLACK, font="Noto Mono").set_opacity(0),
            Paragraph("_", color=BLACK, font="Noto Mono").set_opacity(0),
            Paragraph(x, color=WHITE, font="Noto Mono"),
        ),
        element_to_mobject_config: dict = {},
        arrange_in_grid_config: dict = {},
        line_config: dict = {},
        **kwargs,
    ):
        table_data = [["_" if e is None else e for e in row] for row in table]
        super().__init__(
            table_data,
            row_labels,
            col_labels,
            top_left_entry,
            v_buff,
            h_buff,
            include_outer_lines,
            add_background_rectangles_to_entries,
            entries_background_color,
            include_background_rectangle,
            background_rectangle_color,
            element_to_mobject,
            element_to_mobject_config,
            arrange_in_grid_config,
            line_config,
            **kwargs,
        )

        mob_deque = deque([deque(row) for row in self.mob_table])
        self.mob_table = mob_deque

        self.placeholder = VGroup(  # Hacky hotfix to block size
            Paragraph("|", color=BLACK, font="Noto Mono").set_opacity(0),
            Paragraph("_", color=BLACK, font="Noto Mono").set_opacity(0),
        )

        self.remove(*self.get_vertical_lines())
        self.remove(*self.get_horizontal_lines())
        self.center()

        self.reference = self.get_entries((1, 1))
        self.reference_height = self.reference.height

        # Set placeholders for empty elements
        for row in range(len(table)):
            for col in range(len(table[0])):
                if table[row][col] is None:
                    self.insert_element(None, (row + 1, col + 1))

    def get_reference_scale(self):
        return self.reference.height / self.reference_height

    def _scaled_organize_mob_table(self, table: Iterable[Iterable[VMobject]]) -> VGroup:
        help_table = VGroup()
        for i, row in enumerate(table):
            for j, _ in enumerate(row):
                help_table.add(table[i][j])
        help_table.arrange_in_grid(
            rows=len(table),
            cols=len(table[0]),
            buff=(
                self.h_buff * self.get_reference_scale(),
                self.v_buff * self.get_reference_scale(),
            ),
            **self.arrange_in_grid_config,
        )
        return help_table

    def insert_element(self, element: str | None, pos: Sequence[int] = (1, 1)):
        old_dimensions = (self.width, self.height)
        old_center = self.get_center()

        v_pos = pos[0] - 1
        h_pos = pos[1] - 1
        v_size = len(self.mob_table)
        h_size = len(self.mob_table[0])

        new = (
            self.element_to_mobject(element)
            if element != None
            else self.placeholder.copy()
        )
        entry = self.get_entries((1, 1))
        # print(self.reference.height, self.reference.width)
        new.scale(self.get_reference_scale())
        # print(new.height, new.width)
        if (h_pos >= 0 and h_pos < h_size) and (v_pos >= 0 and v_pos < v_size):
            old = self.mob_table[v_pos][h_pos]

            new.move_to(old)
            self.elements.remove(old)
            self.elements.insert(v_pos * h_size + h_pos, new)

            if old == self.reference:  # Reset reference element if removed
                self.reference = new
                self.reference_height = self.reference.height

            self.mob_table[v_pos][h_pos] = new
            self._scaled_organize_mob_table(self.mob_table)
            return

        def new_placeholder():
            placeholder = self.placeholder.copy()
            placeholder.scale(self.get_reference_scale())
            # print("p", placeholder.height, placeholder.width)
            return placeholder

        # Extend dimensions
        extension = (
            (
                v_pos
                if v_pos < 0
                else (0 if (v_pos >= 0 and v_pos < v_size) else v_pos - v_size + 1)
            ),
            (
                h_pos
                if h_pos < 0
                else (0 if (h_pos >= 0 and h_pos < h_size) else h_pos - h_size + 1)
            ),
        )
        for row in self.mob_table:
            if extension[1] < 0:
                row.extendleft([new_placeholder() for _ in range(abs(extension[1]))])
            elif extension[1] > 0:
                row.extend([new_placeholder() for _ in range(extension[1])])

        h_size += abs(extension[1])
        if extension[1] < 0:
            h_pos += abs(extension[1])

        if extension[0] < 0:
            self.mob_table.extendleft(
                [
                    deque([new_placeholder() for _ in range(h_size)])
                    for _ in range(abs(extension[0]))
                ]
            )
            v_pos += abs(extension[0])
        elif extension[0] > 0:
            self.mob_table.extend(
                [
                    deque([new_placeholder() for _ in range(h_size)])
                    for _ in range(extension[0])
                ]
            )
        v_size += abs(extension[0])
        self.mob_table[v_pos][h_pos] = new

        # Reorder grid
        self._scaled_organize_mob_table(self.mob_table)
        # print("max_width", max([e.width for row in self.mob_table for e in row]))

        # Add to group
        row_offset = 0
        if extension[0] < 0:
            row_offset = abs(extension[0])
            for row in range(abs(extension[0])):
                for col, element in enumerate(self.mob_table[row]):
                    self.elements.insert(row * h_size + col, element)
        if extension[1] != 0:
            for row in range(row_offset, v_size - extension[0] - row_offset):
                if extension[1] < 0:
                    for col in range(abs(extension[1])):
                        self.elements.insert(
                            row * h_size + col, self.mob_table[row][col]
                        )
                else:
                    for col in range(h_size - extension[1], h_size):
                        self.elements.insert(
                            row * h_size + col, self.mob_table[row][col]
                        )
        if extension[0] > 0:
            for row in range(v_size - extension[0], v_size):
                for col, element in enumerate(self.mob_table[row]):
                    self.elements.insert(row * h_size + col, element)
        pass

        # Restore original position
        self.move_to(
            old_center
            + (
                math.copysign(1, extension[1]) * (self.width - old_dimensions[0]) * 0.5,
                -math.copysign(1, extension[0])
                * (self.height - old_dimensions[1])
                * 0.5,
                0,
            )
        )


class GenerateMaze(Scene):
    def construct(self):
        program = restore_program(CHALLENGE)
        # print(program)

        input = [
            Text(
                unit.cursor_value,
                t2c=(
                    {unit.cursor_value: GREEN}
                    if idx == 0
                    else ({unit.cursor_value: RED} if idx == len(program) - 1 else {})
                ),
                font="Noto Mono",
            )
            for idx, unit in enumerate(program)
        ]
        moves = [
            Text(
                unit.next_op,
                t2c={"U": RED, "C": TEAL, "G": DARK_BLUE, "T": PURPLE, "A": PINK},
                font="Noto Mono",
            )
            for unit in program
        ]
        program_table = MobjectTable(
            [input, moves],
            h_buff=0.2,
            v_buff=0.3,
            row_labels=[
                Text("Program", font="Noto Sans", font_size=30),
                Text("Moves", font="Noto Sans", font_size=34),
            ],
            arrange_in_grid_config={"col_alignment": "l" + "c" * len(program)},
        )
        program_table.remove(*program_table.get_horizontal_lines())
        program_table.remove(*program_table.get_vertical_lines())
        MAX_PROGRAM_WIDTH = 13
        program_cursor_scale = 1.0
        if program_table.width > MAX_PROGRAM_WIDTH:
            program_cursor_scale = MAX_PROGRAM_WIDTH / program_table.width
            program_table.scale_to_fit_width(MAX_PROGRAM_WIDTH)
        program_table.to_corner(UL)

        program_cursor = SurroundingRectangle(
            program_table.get_columns()[1],
            BLUE,
            buff=0.1 * program_cursor_scale,
            stroke_width=max(1, 3 * program_cursor_scale),
        )

        self.add(program_table)
        self.add(program_cursor)

        OP_FONT_SIZE = 35
        op1 = Text("END", font="Noto Sans", font_size=OP_FONT_SIZE, color=RED)
        op2 = Text("RIGHT", font="Noto Sans", font_size=OP_FONT_SIZE, color=TEAL)
        op3 = Text("LEFT", font="Noto Sans", font_size=OP_FONT_SIZE, color=DARK_BLUE)
        op4 = Text("DOWN", font="Noto Sans", font_size=OP_FONT_SIZE, color=PURPLE)
        op5 = Text("UP", font="Noto Sans", font_size=OP_FONT_SIZE, color=PINK)
        ops = [op1, op2, op3, op4, op5]
        op_group = VGroup(*ops).arrange(direction=DOWN, aligned_edge=LEFT)
        op_group.to_edge(LEFT)
        op_group.set_opacity(0.2)
        last_op = None
        match program[0].next_op:
            case "U":  # END
                op1.set_opacity(1)
                last_op = op2
                pass
            case "C":  # MOVE RIGHT
                op2.set_opacity(1)
                last_op = op4
                pass
            case "G":  # MOVE LEFT
                op3.set_opacity(1)
                last_op = op3
                pass
            case "T":  # JMP RIGHT
                op4.set_opacity(1)
                last_op = op4
                pass
            case "A":  # JMP LEFT
                op5.set_opacity(1)
                last_op = op5
                pass
            case _:
                raise Exception(f"Not implemented:", unit)
        self.add(op_group)

        # Maze boundaries
        # max_bounds = Rectangle(RED, 4, 8)
        fit_bounds = Rectangle(BLUE, 3, 7)
        # max_bounds.center()
        # fit_bounds.center()
        # self.add(max_bounds)
        # self.add(fit_bounds)

        grid = Grid([[None]])

        cursor = SurroundingRectangle(grid.get_cell((1, 1)), BLUE)
        cursor_height = cursor.height

        def update_cursor_scale(self: SurroundingRectangle):
            self.scale_to_fit_height(grid.get_reference_scale() * cursor_height)
            self.set_stroke(width=max(1, 3 * grid.get_reference_scale()))

        cursor.add_updater(update_cursor_scale)

        self.add(cursor)
        self.add(grid)

        self.play(
            FadeIn(program_table),
            FadeIn(program_cursor),
            FadeIn(op_group),
            FadeIn(cursor),
        )

        def rescale(grid: Grid):
            if grid.width > fit_bounds.width:
                return grid.animate.scale_to_fit_width(fit_bounds.width)
            if grid.height > fit_bounds.height:
                return grid.animate.scale_to_fit_height(fit_bounds.height)

            return grid.animate

        block_index = 0
        indentation = 0
        min_vertical = 0
        min_horizontal = 0
        for idx, unit in enumerate(program):
            grid_v = block_index - min_vertical + 1
            grid_h = indentation - min_horizontal + 1

            grid.insert_element(unit.cursor_value, (grid_v, grid_h))

            element = grid.get_entries((grid_v, grid_h))
            if idx == 0:
                element.color = GREEN
            elif idx == len(program) - 1:
                element.color = RED
            self.play(
                FadeIn(element),
                run_time=0.3,
            )

            next_op = None
            match program[idx].next_op:
                case "U":  # END
                    op1.set_opacity(1)
                    next_op = op1
                    pass
                case "C":  # MOVE RIGHT
                    op2.set_opacity(1)
                    next_op = op2
                    pass
                case "G":  # MOVE LEFT
                    op3.set_opacity(1)
                    next_op = op3
                    pass
                case "T":  # JMP RIGHT
                    op4.set_opacity(1)
                    next_op = op4
                    pass
                case "A":  # JMP LEFT
                    op5.set_opacity(1)
                    next_op = op5
                    pass
                case _:
                    raise Exception(f"Not implemented:", unit)
            if last_op == next_op:
                self.wait(0.6)
            else:
                self.play(
                    last_op.animate(rate_func=rate_functions.ease_out_cubic).set_opacity(0.2),
                    next_op.animate.set_opacity(1),
                    run_time=0.6,
                )
                last_op = next_op

            # Handle ops
            match unit.next_op:
                case "U":  # END
                    # We're done, do not add new field
                    break
                case "C":  # MOVE RIGHT
                    indentation += 1
                    pass
                case "G":  # MOVE LEFT
                    indentation -= 1
                    pass
                case "T":  # JMP RIGHT
                    block_index += 1
                    pass
                case "A":  # JMP LEFT
                    block_index -= 1
                    pass
                case _:
                    raise Exception(f"Not implemented:", unit)

            grid_v = block_index - min_vertical + 1
            grid_h = indentation - min_horizontal + 1
            min_vertical = min(min_vertical, block_index)
            min_horizontal = min(min_horizontal, indentation)
            grid.insert_element(None, (grid_v, grid_h))

            grid_v = block_index - min_vertical + 1
            grid_h = indentation - min_horizontal + 1
            if len(cursor.get_updaters()) == 2:
                cursor.remove_updater(cursor.get_updaters()[1])
            cursor_anchor = grid.get_entries((grid_v, grid_h))
            self.play(
                program_cursor.animate.move_to(program_table.get_columns()[idx + 2]),
                cursor.animate.move_to(cursor_anchor),
                run_time=0.3,
            )

            cursor.add_updater(lambda self: self.move_to(cursor_anchor))
            self.play(rescale(grid).center(), run_time=0.7)

        # Add walls and whitespace
        blocks, offset_left = generate_blocks(program)
        blocks = [block for _, block in sorted(blocks.items())]

        new_entries = []

        WHITESPACE_OPACITY = 0.5
        for idx, block in enumerate(blocks):
            if idx == 0:
                grid.insert_element(WALL, (1, 0))
            else:
                grid.insert_element(WALL, (idx + 1, 1))

            wall = grid.get_entries((idx + 1, 1))
            wall.set_color(LIGHT_BROWN)
            new_entries.append(wall)

            last_idx = max(block.values.keys()) + offset_left
            for pos in range(last_idx):
                if not (pos - offset_left) in block.values:
                    grid.insert_element("␣", (idx + 1, pos + 2))
                    entry = grid.get_entries((idx + 1, pos + 2))
                    entry.set_opacity(WHITESPACE_OPACITY)
                    new_entries.append(entry)

            if idx != len(blocks) - 1:
                grid.insert_element("↵", (idx + 1, last_idx + 3))
                entry = grid.get_entries((idx + 1, last_idx + 3))
                entry.set_opacity(WHITESPACE_OPACITY)
                new_entries.append(entry)

        self.play([FadeIn(entry) for entry in new_entries])
        self.wait(duration=3)


with tempconfig({"quality": "high_quality", "preview": True}):
    scene = GenerateMaze()
    scene.render()
