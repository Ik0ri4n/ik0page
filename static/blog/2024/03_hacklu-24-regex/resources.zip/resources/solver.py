import string
from dataclasses import dataclass
import pwn

# I left the names I used during the CTF in comments, when I renamed things for clarity

ALPHABET = string.ascii_letters + string.digits
ALPHABET_LEN = len(ALPHABET)

# GrimoireOfTongues mapping tables
GOT = {
    "G": "CV9UQG0RAh8wcfuqBsXNt2WPExOKe5dmY4oJLZ6vFjga1ry7lD3MSnkHIbizpToUY3eE5CP2LRFQdqZ6svTBSin0lbHKkVMOtzJ7r8D4w1WcGN9jpAIuamXxfhyg",
    "C": "6q5PAC82RnbigxuLhkmHoIXptvdaBSswYf4EOFyJ7KZDMe3GVjlUrTzcW1N90QWxNPRke3pTrE5JA4HngO0KwZQXDubqItLdV1iYG82omcasMfC6vS9Byhz7UjlF",
    "A": "6DCzPVlAkeBQ38W5NyXvEth4rUdu0LSxo1iJYIF9RGnjwsgqTbp7Hma2OfMKcZvti5C0aZMPcx2QIuJXFEmGYbjl13ToRrhwp9D8HWenOA6NfUzsV7kqKyBL4gdS",
    "T": "Tkor9invyBJal7jH4ZcOuhdetp6g5WsAY0I3MqXPC1NKzUFE2R8DGLVSwfxbQm1zD57CjauGRqpwnFcEOLliQgH39IvVdAeokhBTS02ZMNYtPsxUrKXyf64mWb8J",
    "U": "m6V4nulF71Segfbt08GIT2P3ZRxpN5EqHYXJdLOQhAayKcCswoWjvUrz9iMDBkZhw1YG8OJ9yCX4SuQgzl5BTfR3v2qUna7rAVFjHde0IKNkcE6boWmtsxMDLPpi",
}

# Moves and pattern letters
START = set("lLuY7DGbtSHTP")
END = set("Ma6xXUfg3Rpn9")
VALID = set("X2aM6wg3RpfcxCFvrV95WnU81")
NON_END = VALID.difference(END)
WALL = "N"  # mzZJiN4dEAsk; JUMP
MOVES = ["G", "C", "A", "T"]  # OPS

PADDING = 64


# Mapping and reverse mapping for a given group/move key
def GOT_map(key: str, char: str) -> str:
    first_idx = GOT[key].index(char)
    return GOT[key][first_idx + ALPHABET_LEN]


def GOT_reverse(key: str, char: str) -> str:
    second_idx = GOT[key][ALPHABET_LEN:].index(char)
    return GOT[key][second_idx]


# Functions to restore moves
def start(expected: str):
    out = []
    for op in MOVES:
        prev = GOT_reverse(op, expected)
        if prev in START:
            out.append(op)

    assert len(out) == 1
    return out[0], GOT_reverse(out[0], expected)


def next_op(expected: str):
    out = []
    for op in MOVES:
        prev = GOT_reverse(op, expected)
        if prev in NON_END:
            out.append(op)

    assert len(out) == 1
    return out[0], GOT_reverse(out[0], expected)


def end(expected: str):
    out = []
    for op in MOVES:
        prev = GOT_reverse(op, expected)
        if prev in END:
            out.append(op)

    assert len(out) == 1
    return out[0], GOT_reverse(out[0], expected)


@dataclass
class ProgramUnit:
    cursor_value: str
    next_op: str


@dataclass
class Block:
    values: dict[int, str]


def build_block(block: Block, offset_left: int):
    cell_count = max(block.values.keys()) + offset_left + 1
    cells = [" "] * cell_count

    for idx, value in block.values.items():
        cells[idx + offset_left] = value
        pass

    return "".join(cells)


def restore_program(challenge: str) -> list[ProgramUnit]:
    end_mark = GOT_reverse("U", challenge[-1])

    prog: list[ProgramUnit] = []
    op, value = start(challenge[0])
    assert value in START, value
    prog.append(ProgramUnit(value, op))

    for out in challenge[1:-1]:
        op, value = next_op(out)
        prog.append(ProgramUnit(value, op))
        pass

    prog.append(ProgramUnit(end_mark, "U"))
    return prog


def generate_blocks(program: list[ProgramUnit]):
    blocks: dict[int, Block] = {}
    block_index = 0
    indentation = 0
    for unit in program:
        if block_index not in blocks:
            blocks[block_index] = Block(values={})

        # Set value at cursor in current block
        blocks[block_index].values[indentation] = unit.cursor_value

        # Handle ops
        match unit.next_op:
            case "U":  # END
                # Nothing to do here
                pass
            case "C":  # MOVE RIGHT
                indentation += 1
                pass
            case "G":  # MOVE LEFT
                indentation -= 1
                pass
            case "T":  # JMP RIGHT
                block_index += 1
                pass
            case "A":  # JMP LEFT
                block_index -= 1
                pass
            case _:
                raise Exception(f"Not implemented:", unit)

    min_indentation = 0
    for block in blocks.values():
        min_indentation = min(min_indentation, min(block.values.keys()))

    offset_left = -min_indentation

    return blocks, offset_left


def solve_challenge(challenge: str):
    program = restore_program(challenge)

    blocks, offset_left = generate_blocks(program)

    # I used " "*PADDING, but this is cleaner
    program_out = WALL * 2 + WALL.join(
        [build_block(b, offset_left) for _, b in sorted(blocks.items())]
    )
    return program_out


if __name__ == "__main__":
    with pwn.remote("regex.flu.xxx", 1337) as conn:
        for round in range(42):
            conn.recvuntil(b"Please rephrase this verse in your own words:\n")
            challenge = conn.recvline(keepends=False).decode()
            conn.sendlineafter(b"Your version:\n", solve_challenge(challenge).encode())
        conn.interactive()
