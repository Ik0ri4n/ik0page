// Decompiled with JetBrains decompiler
// Type: REGenerating_EXperience.Program
// Assembly: REGenerating-EXperience, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F074C5D6-2432-4618-9C85-1975A6EF2D58
// Assembly location: C:\Users\Finn\Downloads\REGenerating-EXperience.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

#nullable enable
namespace REGenerating_EXperience
{
  public class Program
  {
    private static readonly Regex RuneAlchemist = new Regex("(?=(?<Q>.*?(?<F>[lLuY7DGbtSHTP])))\\A(?:(?:(?<U>)(?<=\\A(?=\\k<Q>(?<=[Ma6xXUfg3Rpn9])).*)|(?<C>)(?<=\\A(?=\\k<Q>(?<F>[X2aM6wg3RpfcxCFvrV95WnU81])(?<=(?<Q>\\A.*))).*)|(?<G>)(?<=\\A(?=\\k<Q>(?<=(?<F>[8v1FRgx9cnfWaCVXM5rw2p6U3])(?<=(?<Q>\\A.*)).)).*)|(?<T>)(?<=\\A(?=\\k<Q>(?>(?<=(?<=[ksZ4NJiAmzEd])(?<X>[^kJNEmz4isAZd])*[^dkzJENsmZ4Ai])[^NsimJdkzA4EZ]*[N4msZJkdiAzE](?<-X>[^mzZJiN4dEAsk])*(?(X)(?!)))(?<F>[VR8wp9fnMavFr5CUcgXW26x13])(?<=(?<Q>\\A.*))).*)|(?<A>)(?<=\\A(?=\\k<Q>(?<=(?=(?>(?<-X>[^AkNiZJm4sdzE])*(?(X)(?!)))(?<F>[rFx1XRVfwvaWMn5U68pc3g9C2])(?s:(?<=(?<Q>\\A.*))))(?>(?<=[dAiZz4mNJksE])[^Jkz4EsNZmAid]*[AZ4mNisJzEkd](?<=[NEkds4zmiJAZ])(?<X>[^ZJ4imAsNzdEk])*[^di4EsZNJzAmk]))).*)).(?<=\\A(?=(?<R>(?<J>\\k<Q>))(?<-Q>)).*)(?<=\\A(?:(?<=\\A(?=(?<R>\\k<Q>)(?<!\\k<J>)(?<-Q>)).*).)*.)(?<=\\A(?:(?<=\\A(?=\\k<R>(?<=(?<Q>\\A.*))(?<-R>)).*).)*))+?(?(U)|(?!))", RegexOptions.Multiline | RegexOptions.Compiled | RegexOptions.Singleline);
    private static readonly Dictionary<char, string> GrimoireOfTongues = new Dictionary<char, string>()
    {
      {
        'G',
        "CV9UQG0RAh8wcfuqBsXNt2WPExOKe5dmY4oJLZ6vFjga1ry7lD3MSnkHIbizpToUY3eE5CP2LRFQdqZ6svTBSin0lbHKkVMOtzJ7r8D4w1WcGN9jpAIuamXxfhyg"
      },
      {
        'C',
        "6q5PAC82RnbigxuLhkmHoIXptvdaBSswYf4EOFyJ7KZDMe3GVjlUrTzcW1N90QWxNPRke3pTrE5JA4HngO0KwZQXDubqItLdV1iYG82omcasMfC6vS9Byhz7UjlF"
      },
      {
        'A',
        "6DCzPVlAkeBQ38W5NyXvEth4rUdu0LSxo1iJYIF9RGnjwsgqTbp7Hma2OfMKcZvti5C0aZMPcx2QIuJXFEmGYbjl13ToRrhwp9D8HWenOA6NfUzsV7kqKyBL4gdS"
      },
      {
        'T',
        "Tkor9invyBJal7jH4ZcOuhdetp6g5WsAY0I3MqXPC1NKzUFE2R8DGLVSwfxbQm1zD57CjauGRqpwnFcEOLliQgH39IvVdAeokhBTS02ZMNYtPsxUrKXyf64mWb8J"
      },
      {
        'U',
        "m6V4nulF71Segfbt08GIT2P3ZRxpN5EqHYXJdLOQhAayKcCswoWjvUrz9iMDBkZhw1YG8OJ9yCX4SuQgzl5BTfR3v2qUna7rAVFjHde0IKNkcE6boWmtsxMDLPpi"
      }
    };
    private static readonly string? Mantra = Environment.GetEnvironmentVariable("FLAG") ?? "flag{fake}";
    private static readonly string Welcome = "\n              Welcome to              \n                ~ the ~                \n   \uD83D\uDC86✨ REGenerating EXperience ✨\uD83D\uDC86   \n\n      Let your sore body rest and      \n      allow these soothing brain-      \n    teasers to tingle your neurons!    \n";
    private static readonly string Promising = "\nPromising. Let's continue.\n";
    private static readonly string SeeYouLater = "\n\n      You don't seem ready for our     \n    experience yet, and that's okay.   \n   We'll be happy to welcome you back  \n       once you're fully relaxed.      \n\n       Good luck on your journey!      \n\n                  \uD83E\uDE75                   \n";
    private static readonly string Goodbye = "\n         You have proven your\n           ability to relax\n          and take full control\n           of your senses.\n\n       You are now ready to face\n            the world with\n            a clear mind.\n\n        Please take this mantra\n            with you on your\n            journey ahead:\n";

    private static void Main(string[] args)
    {
      Console.WriteLine(Program.Welcome);
      for (int index = 0; index < 42; ++index)
      {
        if (Program.Tingle())
        {
          Console.WriteLine(Program.Promising);
        }
        else
        {
          Console.WriteLine(Program.SeeYouLater);
          return;
        }
      }
      Console.WriteLine();
      Console.WriteLine(Program.Goodbye);
      Console.WriteLine();
      Console.WriteLine(Program.Mantra);
      Console.WriteLine();
    }

    private static bool Tingle()
    {
      string str = Program.WeaveWords(EternalSourceOfWisdom.Generate()) ?? throw new Exception("Impossible, this cannot be!");
      Console.WriteLine("Please rephrase this verse in your own words:");
      Console.WriteLine(str);
      Console.WriteLine("Your version:");
      string input = Console.ReadLine();
      return input != null && Program.WeaveWords(input) == str;
    }

    private static string? WeaveWords(string input)
    {
      Match m = Program.RuneAlchemist.Match(input);
      if (!m.Success)
        return (string) null;
      Queue<char> charQueue = new Queue<char>(Program.GrimoireOfTongues.Keys.Select(k => new
      {
        k = k,
        g = m.Groups[k.ToString()]
      }).SelectMany(
        _param1 => _param1.g.Captures.Cast<Capture>(), (_param1, c) => new
        {
          \u003C\u003Eh__TransparentIdentifier0 = _param1,
          c = c
        }
      ).OrderBy(_param1 => _param1.c.Index).Select(_param1 => _param1.\u003C\u003Eh__TransparentIdentifier0.k));
      StringBuilder stringBuilder = new StringBuilder();
      foreach (Capture capture in m.Groups["F"].Captures)
      {
        char key = charQueue.Dequeue();
        stringBuilder.Append(Program.GrimoireOfTongues[key][Program.GrimoireOfTongues[key].IndexOf(capture.Value) + 62]);
      }
      return stringBuilder.ToString();
    }
  }
}
